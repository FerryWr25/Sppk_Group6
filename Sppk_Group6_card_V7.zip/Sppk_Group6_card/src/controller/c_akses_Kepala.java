package controller;

import MetodeSmart.smartMethod;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicBorders;
import model.m_pengguna;
import views.v_cardKepala;

public class c_akses_Kepala {

    private v_cardKepala is_v;
    private String username;
    private model.m_pengguna is_m;
    private ImageIcon activeBTN, offBtn;
    private smartMethod is_metode;
    ImageIcon activeDash, unactiveDash, activeRob, unactiveRob, activeAra, unactiveAra, activeLib, unactiveLib, activeLah, unactiveLah;
    String removeItem;

    public c_akses_Kepala(String username) throws SQLException {
        this.username = username;
        is_m = new m_pengguna();
        is_v = new v_cardKepala();
        is_v.setVisible(true);
        is_v.getPanel_content().removeAll();
        is_v.getPanel_content().repaint();
        is_v.getPanel_content().revalidate();
        is_v.getTableLahan(is_m.getData_Lahan());
        is_v.getLabelKeteranganRobusta().setText(is_m.get_KetRobusta() + " Lahan masa tanam");
        is_v.getLabelKeteranganArabica().setText(is_m.get_KetArabica() + " Lahan masa tanam");
        is_v.getLabelKeteranganLiberica().setText(is_m.get_KetLiberica() + " Lahan masa tanam");
        is_v.getLabelKeteranganMasaPanen().setText(is_m.get_KetPanen() + " Lahan masa panen");
        is_v.getLabelKeteranganPemulihan().setText(is_m.get_KetPemulihan() + " Lahan masa pemulihan");
        for (int i = 0; i < is_m.get_ID_Lahan().length; i++) {
            is_v.getCombo_idLahan().addItem(is_m.get_ID_Lahan()[i]);
        }
        for (int i = 0; i < is_m.get_ID_Lahan().length; i++) {
            is_v.getCombo_idLahan1().addItem(is_m.get_ID_Lahan()[i]);
        }
        for (int i = 0; i < is_m.get_ID_Lahan().length; i++) {
            is_v.getCombo_idLahanLiberica().addItem(is_m.get_ID_Lahan()[i]);
        }
        show_unsHowRecomendasi("hide1");
        show_unsHowRecomendasi("hide2");
        show_unsHowRecomendasi("hide3");
        is_v.getPanel_content().add(is_v.getPanel_dashboard());
        is_v.getPanel_content().repaint();
        is_v.getPanel_content().revalidate();
        this.activeBTN = new ImageIcon(getClass().getResource("/image/activeBtn2.png"));
        this.offBtn = new ImageIcon(getClass().getResource("/image/awalBtn_1_1.png"));
        this.activeDash = new ImageIcon(getClass().getResource("/image/activeDashboard.png"));
        this.unactiveDash = new ImageIcon(getClass().getResource("/image/unactiveDashboard.png"));
        this.activeRob = new ImageIcon(getClass().getResource("/image/activeRobusta.png"));
        this.unactiveRob = new ImageIcon(getClass().getResource("/image/unactiveRobusta.png"));
        this.activeAra = new ImageIcon(getClass().getResource("/image/activeArabica.png"));
        this.unactiveAra = new ImageIcon(getClass().getResource("/image/unactiveArabica.png"));
        this.activeLib = new ImageIcon(getClass().getResource("/image/activeLiberica.png"));
        this.unactiveLib = new ImageIcon(getClass().getResource("/image/unactiveLiberica.png"));
        this.activeLah = new ImageIcon(getClass().getResource("/image/activeLahan.png"));
        this.unactiveLah = new ImageIcon(getClass().getResource("/image/unactiveLahan.png"));
        is_v.getBtn_dashboard().setIcon(activeDash);
        is_v.getBtn_dashboard().setRolloverEnabled(false);
        is_v.getBtn_robusta().setRolloverEnabled(false);
        is_v.getBtn_arabica().setRolloverEnabled(false);
        is_v.getBtn_Liberica().setRolloverEnabled(false);
        is_v.getBtn_dataLahan().setRolloverEnabled(false);
        is_v.getBtn_batalRobusta().setVisible(false);
        is_v.getBtn_batal_arabica().setVisible(false);
        is_v.getBtn_batalLiberica().setVisible(false);
        is_v.getBtn_dashboard().addActionListener(new dashboard_Listener());
        is_v.getBtn_robusta().addActionListener(new lahanRobusta_Listener());
        is_v.getBtn_arabica().addActionListener(new lahanArabica_Listener());
        is_v.getBtn_Liberica().addActionListener(new lahanLiberica_Listener());
        is_v.getBtn_dataLahan().addActionListener(new lahanDataLahan_Listener());
        is_v.getBtn_logout().addActionListener(new log_Out_Listener());
        is_v.getBtn_minimize().addMouseListener(new minimizeListener());
        is_v.getBtnAnalisis_robusta().addActionListener(new analisisRobusta());
        is_v.getBtnAnalisis_arabica().addActionListener(new analisisArabica());
        is_v.getBtnAnalisis_Liberica().addActionListener(new analisisLiberica());
        is_v.getBtn_Dashrobusta().addActionListener(new lahanDataLahan_Listener());
        is_v.getBtn_DashArabica().addActionListener(new lahanDataLahan_Listener());
        is_v.getBtn_DashLiberica().addActionListener(new lahanDataLahan_Listener());
        is_v.getBtn_DashPanen().addActionListener(new lahanDataLahan_Listener());
        is_v.getBtn_DashPemulihan().addActionListener(new lahanDataLahan_Listener());
        is_v.getBtn_batalRobusta().addActionListener(new batalRobusta());
        is_v.getBtn_batal_arabica().addActionListener(new batalArabica());
        is_v.getBtn_batalLiberica().addActionListener(new batalLiberica());
        is_v.getCombo_idLahan().addItemListener(new ItemChangeListener_Robusta());
        is_v.getCombo_idLahanArabica().addItemListener(new ItemChangeListener_Arabica());
        is_v.getCombo_idLahanLiberica().addItemListener(new ItemChangeListener_Liberica());
        is_v.getBtn_recomendasikan_robusta().addActionListener(new recomendasi_Listener_Robusta());
        is_v.getBtn_recomendasikan_arabica().addActionListener(new recomendasi_Listener_Arabica());
        is_v.getBtn_recomendasikan_liberica().addActionListener(new recomendasi_Listener_Liberica());

    }

    
    private class recomendasi_Listener_Robusta implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (is_v.showOption("Anda Yakin Merekomendasikan tanam Robusta pada lahan " + is_v.getCombo_idLahan().getSelectedItem() + "") == JOptionPane.OK_OPTION) {
                try {
                    if (is_m.updateStatusLahan_toRecomendasi(is_v.getCombo_idLahan().getSelectedItem() + "")) {
                        is_v.showMessage("Recomendasi tanam Lahan " + is_v.getCombo_idLahan().getSelectedItem() + "" + " Berhasil dimasukkan");
                        removeItem = is_v.getCombo_idLahan().getSelectedItem() + "";
                        is_v.getCombo_idLahan().removeItem(removeItem);
                        is_v.getCombo_idLahanLiberica().removeItem(removeItem);
                        is_v.getCombo_idLahanArabica().removeItem(removeItem);
                    } else {
                        System.out.println("gagal update");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(c_akses_Kepala.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }
    private class recomendasi_Listener_Arabica implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (is_v.showOption("Anda Yakin Merekomendasikan tanam Arabica pada lahan " + is_v.getCombo_idLahanArabica().getSelectedItem() + "") == JOptionPane.OK_OPTION) {
                try {
                    if (is_m.updateStatusLahan_toRecomendasi_Arabica(is_v.getCombo_idLahanArabica().getSelectedItem() + "")) {
                        is_v.showMessage("Recomendasi tanam Lahan " + is_v.getCombo_idLahanArabica().getSelectedItem() + "" + " Berhasil dimasukkan");
                        removeItem = is_v.getCombo_idLahanArabica().getSelectedItem() + "";
                        is_v.getCombo_idLahan().removeItem(removeItem);
                        is_v.getCombo_idLahanLiberica().removeItem(removeItem);
                        is_v.getCombo_idLahanArabica().removeItem(removeItem);
                    } else {
                        System.out.println("gagal update");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(c_akses_Kepala.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }
    private class recomendasi_Listener_Liberica implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (is_v.showOption("Anda Yakin Merekomendasikan tanam Liberica pada lahan " + is_v.getCombo_idLahanLiberica().getSelectedItem() + "") == JOptionPane.OK_OPTION) {
                try {
                    if (is_m.updateStatusLahan_toRecomendasi_Liberica(is_v.getCombo_idLahanLiberica().getSelectedItem() + "")) {
                        is_v.showMessage("Recomendasi tanam Lahan " + is_v.getCombo_idLahanLiberica().getSelectedItem() + "" + " Berhasil dimasukkan");
                        removeItem = is_v.getCombo_idLahanLiberica().getSelectedItem() + "";
                        is_v.getCombo_idLahan().removeItem(removeItem);
                        is_v.getCombo_idLahanLiberica().removeItem(removeItem);
                        is_v.getCombo_idLahanArabica().removeItem(removeItem);
                    } else {
                        System.out.println("gagal update");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(c_akses_Kepala.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }

    public void resetContent() {
        is_v.getLabel_rhb().setText("");
        is_v.getLabel_rhc().setText("");
        is_v.getLabel_suhu().setText("");
        is_v.getLabel_curahHujan().setText("");
        is_v.getLabel_TTanah().setText("");
        is_v.getLabel_drainase().setText("");
        is_v.getLabel_ketinggian().setText("");
        is_v.getLabel_erosi().setText("");
        is_v.getLabel_lereng().setText("");
        is_v.getLabel_rhb1().setText("");
        is_v.getLabel_rhc1().setText("");
        is_v.getLabel_suhu1().setText("");
        is_v.getLabel_curahHujan1().setText("");
        is_v.getLabel_TTanah1().setText("");
        is_v.getLabel_drainase1().setText("");
        is_v.getLabel_ketinggian1().setText("");
        is_v.getLabel_erosi1().setText("");
        is_v.getLabel_lereng1().setText("");
        is_v.getLabel_rhb2().setText("");
        is_v.getLabel_rhc2().setText("");
        is_v.getLabel_suhu2().setText("");
        is_v.getLabel_curahHujan2().setText("");
        is_v.getLabel_TTanah2().setText("");
        is_v.getLabel_drainase2().setText("");
        is_v.getLabel_ketinggian2().setText("");
        is_v.getLabel_erosi2().setText("");
        is_v.getLabel_lereng2().setText("");
        is_v.getLabelHasil().setText("");
        is_v.getLabelHasilLiberica().setText("");
        is_v.getLabelHasil_arabica().setText("");
        show_unsHowRecomendasi("hide1");
        show_unsHowRecomendasi("hide2");
        show_unsHowRecomendasi("hide3");

    }

    private class ItemChangeListener_Robusta implements ItemListener {

        @Override
        public void itemStateChanged(ItemEvent e) {
            try {
                if (is_v.getCombo_idLahan().getSelectedItem().equals("Pilih disini....")) {
                    is_v.getBtnAnalisis_robusta().setVisible(false);
                    System.out.println("gak boleh");
                } else {
                    setDataRobusta(Integer.parseInt(is_v.getCombo_idLahan().getSelectedItem() + ""));
                    is_v.getBtnAnalisis_robusta().setVisible(true);
                }
            } catch (SQLException ex) {
                Logger.getLogger(c_akses_Kepala.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    private class ItemChangeListener_Arabica implements ItemListener {

        @Override
        public void itemStateChanged(ItemEvent e) {
            try {
                if (is_v.getCombo_idLahanArabica().getSelectedItem().equals("Pilih disini....")) {
                    System.out.println("gak boleh");
                    is_v.getBtnAnalisis_arabica().setVisible(false);
                } else {
                    setDataArabica(Integer.parseInt(is_v.getCombo_idLahanArabica().getSelectedItem() + ""));
                    is_v.getBtnAnalisis_arabica().setVisible(true);
                }
            } catch (SQLException ex) {
                Logger.getLogger(c_akses_Kepala.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    private class ItemChangeListener_Liberica implements ItemListener {

        @Override
        public void itemStateChanged(ItemEvent e) {
            try {
                if (is_v.getCombo_idLahanLiberica().getSelectedItem().equals("Pilih disini....")) {
                    System.out.println("gak boleh");
                    is_v.getBtnAnalisis_Liberica().setVisible(false);
                } else {
                    setDataLiberica(Integer.parseInt(is_v.getCombo_idLahanLiberica().getSelectedItem() + ""));
                     is_v.getBtnAnalisis_Liberica().setVisible(true);
                }
            } catch (SQLException ex) {
                Logger.getLogger(c_akses_Kepala.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    public void show_unsHowRecomendasi(String perintah) {
        if (perintah.equalsIgnoreCase("hide1")) {
            is_v.getBtn_recomendasikan_robusta().setVisible(false);
            is_v.getLabelinformasi_robu1().setVisible(false);
            is_v.getLabelinformasi_robu2().setVisible(false);
            is_v.getLabelinformasi_robu3().setVisible(false);
            is_v.getBtnAnalisis_robusta().setVisible(true);
        } else if (perintah.equalsIgnoreCase("show1")) {
            is_v.getBtn_recomendasikan_robusta().setVisible(true);
            is_v.getLabelinformasi_robu1().setVisible(true);
            is_v.getLabelinformasi_robu2().setVisible(true);
            is_v.getLabelinformasi_robu3().setVisible(true);
            is_v.getBtn_batalRobusta().setVisible(true);
            is_v.getBtnAnalisis_robusta().setVisible(false);
        } else if (perintah.equalsIgnoreCase("hide2")) {
            is_v.getBtn_recomendasikan_arabica().setVisible(false);
            is_v.getLabelinformasi_ara1().setVisible(false);
            is_v.getLabelinformasi_ara2().setVisible(false);
            is_v.getLabelinformasi_ara3().setVisible(false);
            is_v.getBtnAnalisis_arabica().setVisible(true);
        } else if (perintah.equalsIgnoreCase("show2")) {
            is_v.getBtn_recomendasikan_arabica().setVisible(true);
            is_v.getLabelinformasi_ara1().setVisible(true);
            is_v.getLabelinformasi_ara2().setVisible(true);
            is_v.getLabelinformasi_ara3().setVisible(true);
            is_v.getBtn_batal_arabica().setVisible(true);
            is_v.getBtnAnalisis_arabica().setVisible(false);
        } else if (perintah.equalsIgnoreCase("hide3")) {
            is_v.getBtn_recomendasikan_liberica().setVisible(false);
            is_v.getLabelinformasi_libe1().setVisible(false);
            is_v.getLabelinformasi_libe2().setVisible(false);
            is_v.getLabelinformasi_libe3().setVisible(false);
            is_v.getBtnAnalisis_Liberica().setVisible(true);
        } else if (perintah.equalsIgnoreCase("show3")) {
            is_v.getBtn_recomendasikan_liberica().setVisible(true);
            is_v.getLabelinformasi_libe1().setVisible(true);
            is_v.getLabelinformasi_libe2().setVisible(true);
            is_v.getLabelinformasi_libe3().setVisible(true);
            is_v.getBtn_batalLiberica().setVisible(true);
            is_v.getBtnAnalisis_Liberica().setVisible(false);
        }
    }

    private class batalRobusta implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            is_v.getLabelHasil().setText("");
            show_unsHowRecomendasi("hide1");
            is_v.getBtn_batalRobusta().setVisible(false);
        }

    }

    private class batalArabica implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            is_v.getLabelHasil_arabica().setText("");
            show_unsHowRecomendasi("hide2");
            is_v.getBtn_batal_arabica().setVisible(false);
        }

    }

    private class batalLiberica implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            is_v.getLabelHasilLiberica().setText("");
            show_unsHowRecomendasi("hide3");
            is_v.getBtn_batalLiberica().setVisible(false);
        }

    }

    public void setDataRobusta(int id) throws SQLException {
        is_v.getLabel_rhb().setText("Rhc : " + is_m.get_nRHB(id + "") + "");
        is_v.getLabel_rhc().setText("Rhb : " + is_m.get_nRHC(id + "") + "");
        is_v.getLabel_suhu().setText("Suhu : " + is_m.get_nSuhu(id + "") + "C");
        is_v.getLabel_curahHujan().setText("cHUjan : " + is_m.get_nCHujan(id + "") + "mm");
        is_v.getLabel_TTanah().setText("Tanah : " + is_m.get_nTanah(id + "") + "");
        is_v.getLabel_drainase().setText("Drainase : " + is_m.get_nDrainase(id + "") + "");
        is_v.getLabel_ketinggian().setText("Tinggi : " + is_m.get_nKetinggian(id + "") + "");
        is_v.getLabel_erosi().setText("Erosi : " + is_m.get_nErosi(id + "") + "");
        is_v.getLabel_lereng().setText("Lereng : " + is_m.get_nLereng(id + "") + "%");
    }

    public void setDataArabica(int id) throws SQLException {
        is_v.getLabel_rhb1().setText("Rhc : " + is_m.get_nRHB(id + "") + "");
        is_v.getLabel_rhc1().setText("Rhb : " + is_m.get_nRHC(id + "") + "");
        is_v.getLabel_suhu1().setText("Suhu : " + is_m.get_nSuhu(id + "") + "C");
        is_v.getLabel_curahHujan1().setText("cHUjan : " + is_m.get_nCHujan(id + "") + "mm");
        is_v.getLabel_TTanah1().setText("Tanah : " + is_m.get_nTanah(id + "") + "");
        is_v.getLabel_drainase1().setText("Drainase : " + is_m.get_nDrainase(id + "") + "");
        is_v.getLabel_ketinggian1().setText("Tinggi : " + is_m.get_nKetinggian(id + "") + "");
        is_v.getLabel_erosi1().setText("Erosi : " + is_m.get_nErosi(id + "") + "");
        is_v.getLabel_lereng1().setText("Lereng : " + is_m.get_nLereng(id + "") + "%");
    }

    public void setDataLiberica(int id) throws SQLException {
        is_v.getLabel_rhb2().setText("Rhc : " + is_m.get_nRHB(id + "") + "");
        is_v.getLabel_rhc2().setText("Rhb : " + is_m.get_nRHC(id + "") + "");
        is_v.getLabel_suhu2().setText("Suhu : " + is_m.get_nSuhu(id + "") + "C");
        is_v.getLabel_curahHujan2().setText("cHUjan : " + is_m.get_nCHujan(id + "") + "mm");
        is_v.getLabel_TTanah2().setText("Tanah : " + is_m.get_nTanah(id + "") + "");
        is_v.getLabel_drainase2().setText("Drainase : " + is_m.get_nDrainase(id + "") + "");
        is_v.getLabel_ketinggian2().setText("Tinggi : " + is_m.get_nKetinggian(id + "") + "");
        is_v.getLabel_erosi2().setText("Erosi : " + is_m.get_nErosi(id + "") + "");
        is_v.getLabel_lereng2().setText("Lereng : " + is_m.get_nLereng(id + "") + "%");
    }

    private class analisisRobusta implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                is_metode = new smartMethod(is_m.get_nRHB(is_v.getCombo_idLahan().getSelectedItem() + ""),
                        is_m.get_nRHC(is_v.getCombo_idLahan().getSelectedItem() + ""),
                        is_m.get_nSuhu(is_v.getCombo_idLahan().getSelectedItem() + ""),
                        is_m.get_nCHujan(is_v.getCombo_idLahan().getSelectedItem() + ""),
                        is_m.get_nTanah(is_v.getCombo_idLahan().getSelectedItem() + ""),
                        is_m.get_nDrainase(is_v.getCombo_idLahan().getSelectedItem() + ""),
                        is_m.get_nKetinggian(is_v.getCombo_idLahan().getSelectedItem() + ""),
                        is_m.get_nErosi(is_v.getCombo_idLahan().getSelectedItem() + ""),
                        is_m.get_nLereng(is_v.getCombo_idLahan().getSelectedItem() + ""));
                is_metode.getHasil();
                if (is_metode.getHasil() > 0.65) {
                    is_v.getLabelHasil().setText("Cocok");
                } else if (is_metode.getHasil() >= 0.50 && is_metode.getHasil() < 0.65) {
                    is_v.getLabelHasil().setText("Pertimbangkan");
                } else {
                    is_v.getLabelHasil().setText("Tidak cocok");
                }
            } catch (SQLException ex) {
                Logger.getLogger(c_akses_Kepala.class.getName()).log(Level.SEVERE, null, ex);
            }
            show_unsHowRecomendasi("show1");

        }

    }

    private class analisisArabica implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                is_metode = new smartMethod(is_m.get_nRHB(is_v.getCombo_idLahan1().getSelectedItem() + ""),
                        is_m.get_nRHC(is_v.getCombo_idLahan1().getSelectedItem() + ""),
                        is_m.get_nSuhu(is_v.getCombo_idLahan1().getSelectedItem() + ""),
                        is_m.get_nCHujan(is_v.getCombo_idLahan1().getSelectedItem() + ""),
                        is_m.get_nTanah(is_v.getCombo_idLahan1().getSelectedItem() + ""),
                        is_m.get_nDrainase(is_v.getCombo_idLahan1().getSelectedItem() + ""),
                        is_m.get_nKetinggian(is_v.getCombo_idLahan1().getSelectedItem() + ""),
                        is_m.get_nErosi(is_v.getCombo_idLahan1().getSelectedItem() + ""),
                        is_m.get_nLereng(is_v.getCombo_idLahan1().getSelectedItem() + ""));
                is_metode.getHasil();
                if (is_metode.getHasil() > 0.65) {
                    is_v.getLabelHasil_arabica().setText("Dipertimbangkan");
                } else if (is_metode.getHasil() >= 0.50 && is_metode.getHasil() < 0.65) {
                    is_v.getLabelHasil_arabica().setText("Cocok");
                } else {
                    is_v.getLabelHasil_arabica().setText("Tidak cocok");
                }
            } catch (SQLException ex) {
                Logger.getLogger(c_akses_Kepala.class.getName()).log(Level.SEVERE, null, ex);
            }
            is_v.getBtnAnalisis_arabica().setVisible(false);
            show_unsHowRecomendasi("show2");
        }
    }

    private class analisisLiberica implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                is_metode = new smartMethod(is_m.get_nRHB(is_v.getCombo_idLahanLiberica().getSelectedItem() + ""),
                        is_m.get_nRHC(is_v.getCombo_idLahanLiberica().getSelectedItem() + ""),
                        is_m.get_nSuhu(is_v.getCombo_idLahanLiberica().getSelectedItem() + ""),
                        is_m.get_nCHujan(is_v.getCombo_idLahanLiberica().getSelectedItem() + ""),
                        is_m.get_nTanah(is_v.getCombo_idLahanLiberica().getSelectedItem() + ""),
                        is_m.get_nDrainase(is_v.getCombo_idLahanLiberica().getSelectedItem() + ""),
                        is_m.get_nKetinggian(is_v.getCombo_idLahanLiberica().getSelectedItem() + ""),
                        is_m.get_nErosi(is_v.getCombo_idLahanLiberica().getSelectedItem() + ""),
                        is_m.get_nLereng(is_v.getCombo_idLahanLiberica().getSelectedItem() + ""));
                is_metode.getHasil();
                if (is_metode.getHasil() > 0.65) {
                    is_v.getLabelHasilLiberica().setText("Tidak cocok");
                } else if (is_metode.getHasil() >= 0.50 && is_metode.getHasil() < 0.65) {
                    is_v.getLabelHasilLiberica().setText("Dipertimbangkan");
                } else {
                    is_v.getLabelHasilLiberica().setText("Cocok");
                }
            } catch (SQLException ex) {
                Logger.getLogger(c_akses_Kepala.class.getName()).log(Level.SEVERE, null, ex);
            }
            show_unsHowRecomendasi("show3");
        }

    }

    private class minimizeListener implements MouseListener {

        @Override
        public void mouseClicked(MouseEvent e) {
            minimizeAction();
        }

        @Override
        public void mousePressed(MouseEvent e) {
        }

        @Override
        public void mouseReleased(MouseEvent e) {
        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }

    }

    private void minimizeAction() {
        is_v.minimize();
    }

    private class log_Out_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (is_v.showOption("Anda Yakin akan keluar") == JOptionPane.OK_OPTION) {
                try {
                    is_v.dispose();
                    new c_pengguna(1);
                } catch (SQLException ex) {
                    Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    private class dashboard_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            is_v.getPanel_content().removeAll();
            is_v.getPanel_content().revalidate();
            is_v.getPanel_content().repaint();
            is_v.getPanel_content().add(is_v.getPanel_dashboard());
            is_v.getPanel_content().revalidate();
            is_v.getPanel_content().repaint();
            is_v.getBtn_dashboard().setIcon(activeDash);
            is_v.getBtn_robusta().setIcon(unactiveRob);
            is_v.getBtn_arabica().setIcon(unactiveAra);
            is_v.getBtn_Liberica().setIcon(unactiveLib);
            is_v.getBtn_dataLahan().setIcon(unactiveLah);
            resetContent();
            is_v.getBtn_batalRobusta().setVisible(false);
            is_v.getBtn_batal_arabica().setVisible(false);
            is_v.getBtn_batalLiberica().setVisible(false);
        }

    }

    private class lahanRobusta_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            is_v.getPanel_content().removeAll();
            is_v.getPanel_content().repaint();
            is_v.getPanel_content().revalidate();
            is_v.getPanel_content().add(is_v.getPanel_robusta());
            is_v.getPanel_content().repaint();
            is_v.getPanel_content().revalidate();
            is_v.getBtn_dashboard().setIcon(unactiveDash);
            is_v.getBtn_robusta().setIcon(activeRob);
            is_v.getBtn_arabica().setIcon(unactiveAra);
            is_v.getBtn_Liberica().setIcon(unactiveLib);
            is_v.getBtn_dataLahan().setIcon(unactiveLah);
            resetContent();
            is_v.getBtn_batalRobusta().setVisible(false);
            is_v.getBtn_batal_arabica().setVisible(false);
            is_v.getBtn_batalLiberica().setVisible(false);

        }

    }

    private class lahanArabica_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            is_v.getPanel_content().removeAll();
            is_v.getPanel_content().repaint();
            is_v.getPanel_content().revalidate();
            is_v.getPanel_content().add(is_v.getPanel_arabica());
            is_v.getPanel_content().repaint();
            is_v.getPanel_content().revalidate();
            is_v.getBtn_dashboard().setIcon(unactiveDash);
            is_v.getBtn_robusta().setIcon(unactiveRob);
            is_v.getBtn_arabica().setIcon(activeAra);
            is_v.getBtn_Liberica().setIcon(unactiveLib);
            is_v.getBtn_dataLahan().setIcon(unactiveLah);
            resetContent();
            is_v.getBtn_batalRobusta().setVisible(false);
            is_v.getBtn_batal_arabica().setVisible(false);
            is_v.getBtn_batalLiberica().setVisible(false);
        }

    }

    private class lahanLiberica_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            is_v.getPanel_content().removeAll();
            is_v.getPanel_content().repaint();
            is_v.getPanel_content().revalidate();
            is_v.getPanel_content().add(is_v.getPanel_liberica());
            is_v.getPanel_content().repaint();
            is_v.getPanel_content().revalidate();
            is_v.getBtn_dashboard().setIcon(unactiveDash);
            is_v.getBtn_robusta().setIcon(unactiveRob);
            is_v.getBtn_arabica().setIcon(unactiveAra);
            is_v.getBtn_Liberica().setIcon(activeLib);
            is_v.getBtn_dataLahan().setIcon(unactiveLah);
            resetContent();
            is_v.getBtn_batalRobusta().setVisible(false);
            is_v.getBtn_batal_arabica().setVisible(false);
            is_v.getBtn_batalLiberica().setVisible(false);
        }

    }

    private class lahanDataLahan_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                is_v.getTableLahan(is_m.getData_Lahan());
            } catch (SQLException ex) {
                Logger.getLogger(c_akses_Kepala.class.getName()).log(Level.SEVERE, null, ex);
            }
            is_v.getPanel_content().removeAll();
            is_v.getPanel_content().repaint();
            is_v.getPanel_content().revalidate();
            is_v.getPanel_content().add(is_v.getPanel_dataLahan());
            is_v.getPanel_content().repaint();
            is_v.getPanel_content().revalidate();
            is_v.getBtn_dashboard().setIcon(unactiveDash);
            is_v.getBtn_robusta().setIcon(unactiveRob);
            is_v.getBtn_arabica().setIcon(unactiveAra);
            is_v.getBtn_Liberica().setIcon(unactiveLib);
            is_v.getBtn_dataLahan().setIcon(activeLah);
        }

    }

}
