/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import koneksi.connection;

/**
 *
 * @author helmets
 */
public class m_pengguna extends m_master {

    ResultSet rs;

    public m_pengguna() throws SQLException {
        this.con = new connection();
        con = new connection();
    }

    public boolean getPengguna(String username, String password) throws SQLException {
        String query = "SELECT * FROM `pengguna` WHERE username = '" + username + "' AND Password ='" + password + "'";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return status;
    }

    public String[] get_ID_Lahan() throws SQLException {
        String query = "select id_lahan from lahan where id_status_tanam = 5  ORDER BY id_lahan ASC";
        boolean status = false;
        ResultSet hasil = con.getResult(query);
        String ID[];
        int hitung = 0;
        while (hasil.next()) {
            hitung++;
        }
        hasil.beforeFirst();
        ID = new String[hitung];
        int i = 0;
        while (hasil.next()) {
            ID[i] = hasil.getString(1);
            i++;
        }
        return ID;
    }

    public int getlevel(String username, String password) throws SQLException {
        String query = "SELECT * FROM `pengguna` WHERE username = '" + username + "' AND Password ='" + password + "'";
        int level = 0;
        try {
            level = Integer.valueOf(rs.getString(4));
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return level;
    }

    public int getlevel_Just(String username) throws SQLException {
        String query = "select level FROM `pengguna` where username= '" + username + "'";
        return getDataInt(query);
    }

    public DefaultTableModel getData_Lahan() throws SQLException {
        String kolom[] = {"Id", "Status Lahan", "Nilai RHB", "Nilai RHC", "Suhu", "Curah Hujan", "Tekstur Tanah",
            "Drainase", "Ketinggian", "Resiko Erosi", "Lereng"};
        String query = "select l.id_lahan,s.status,l.nilai_rhb_Lahan,l.nilai_rhc_Lahan,l.Temperatur_suhu,l.Curah_hujan,l.Tekstur_tanah,"
                + "l.Drainase_lahan,"
                + "l.Ketinggian_lahan,l.Resiko_erosi,l.Lereng from lahan l "
                + "join status_tanam s on (l.id_status_tanam=s.id_status_tanam) order by l.id_lahan asc ";
        System.out.println(query);
        return getDataTabel(kolom, query);
    }

    public String[] getLahan_Edit(String id_Lahan) throws SQLException {
        String data[] = new String[12];
        String query = "select * from lahan where id_lahan = " + id_Lahan;
        return getData_ID(query, data);
    }

    public String[] getLahan_EditRobusta(String id_Lahan) throws SQLException {
        String data[] = new String[1];
        String query = "select * from lahan where id_lahan = " + id_Lahan;
        return getData_ID(query, data);
    }

    public boolean updateLahan(int idStatus, int rhb, int rhc, int suhu, int curahHUjan, String Tekstur, String drainase, int ketinggian, String erosi, int lereng) throws SQLException {
        String query = "update set id_status_tanam= " + idStatus + ", nilai_rhb_Lahan= " + rhb + "" + ", nilai_rhc_Lahan= " + rhc + "" + ", Temperatur_suhu= " + suhu + ""
                + ", Curah_hujan= " + curahHUjan + "" + ", Tekstur_tanah= '" + Tekstur + "'" + ", Drainase_lahan= '" + drainase + "'"
                + ", Ketinggian_lahan= " + ketinggian + ""
                + ", Resiko_erosi= '" + erosi + "'"
                + ", Lereng= " + lereng + "";
        System.out.println(query);
        return getStatusQuery(query);
    }

    public boolean updateStatusLahan_eksekusiTanam(String id, String idStatus) throws SQLException {
        String query = "UPDATE `lahan` SET `id_status_tanam` = " + idStatus + " WHERE `id_lahan` = " + id;
        System.out.println(query);
        return getStatusQuery(query);
    }

    public boolean updateStatusLahan_toRecomendasi(String id) throws SQLException {
        String query = "UPDATE `lahan` SET `id_status_tanam` = '6' WHERE `id_lahan` = " + id;
        System.out.println(query);
        return getStatusQuery(query);
    }

    public boolean updateStatusLahan_toRecomendasi_Arabica(String id) throws SQLException {
        String query = "UPDATE `lahan` SET `id_status_tanam` = '7' WHERE `id_lahan` = " + id;
        System.out.println(query);
        return getStatusQuery(query);
    }

    public boolean updateStatusLahan_toRecomendasi_Liberica(String id) throws SQLException {
        String query = "UPDATE `lahan` SET `id_status_tanam` = '8' WHERE `id_lahan` = " + id;
        System.out.println(query);
        return getStatusQuery(query);
    }

    public boolean updateLahanRobusta(String idStatus, String idLahan) throws SQLException {
        String query = "update lahan set id_status_tanam =" + idStatus + " where id_lahan= " + idLahan;
        System.out.println(query);
        return getStatusQuery(query);
    }

    public int getJumlahRobusta_Tanam() throws SQLException {
        String query = "select COUNT(id_status_tanam) from lahan where id_status_tanam = 1";
        return getDataInt(query);
    }

    public boolean insertLahanBaru(int idStatus, int rhb, int rhc, int suhu, int curahHUjan, String Tekstur, String drainase, int ketinggian, String erosi, int lereng) throws SQLException {
        String query = "INSERT INTO `lahan`(`id_lahan`, `id_status_tanam`, `nilai_rhb_Lahan`, `nilai_rhc_Lahan`, `Temperatur_suhu`, `Curah_hujan`, "
                + "`Tekstur_tanah`, `Drainase_lahan`, `Ketinggian_lahan`, `Resiko_erosi`, `Lereng`) VALUES (" + "NULL" + "," + idStatus + "," + rhb + "," + rhc + "," + suhu + "," + curahHUjan + ",'" + Tekstur + "','" + drainase + "',"
                + ketinggian + ",'" + erosi + "'," + lereng + ")";
        System.out.println(query);
        return getStatusQuery(query);
    }

    public int getID_Lahann(String data) throws SQLException {
        String query = "select id_status_tanam from status_tanam where status = '" + data + "' ";
        return getDataInt(query);
    }

    public int getID_Status(String data) throws SQLException {
        String query = "select id_status_tanam from status_tanam where status = '" + data + "' ";
        return getDataInt(query);
    }

    public int getJumlahArabica_Tanam() throws SQLException {
        String query = "select COUNT(id_status_tanam) from lahan where id_status_tanam = 2";
        return getDataInt(query);
    }

    public int getJumlahLiberica_Tanam() throws SQLException {
        String query = "select COUNT(id_status_tanam) from lahan where id_status_tanam = 3";
        return getDataInt(query);
    }

    public DefaultTableModel getData_Robusta() throws SQLException {
        String kolom[] = {"Id", "Status Lahan"};
        String query = "select l.id_lahan, s.status from lahan l join status_tanam s on "
                + "(l.id_status_tanam=s.id_status_tanam) where s.status ='Fase tanam Robusta' order by l.id_lahan ASC";
        return getDataTabel(kolom, query);
    }

    public DefaultTableModel getData_Arabica() throws SQLException {
        String kolom[] = {"Id", "Status Lahan"};
        String query = "select l.id_lahan, s.status from lahan l join status_tanam s on "
                + "(l.id_status_tanam=s.id_status_tanam) where s.status ='Fase tanam Arabica' order by l.id_lahan ASC";
        return getDataTabel(kolom, query);
    }

    public DefaultTableModel getData_Liberica() throws SQLException {
        String kolom[] = {"Id", "Status Lahan"};
        String query = "select l.id_lahan, s.status from lahan l join status_tanam s on "
                + "(l.id_status_tanam=s.id_status_tanam) where s.status ='Fase tanam Liberica' order by l.id_lahan ASC";
        return getDataTabel(kolom, query);
    }

    public DefaultTableModel getData_verifiedLAhan() throws SQLException {
        String kolom[] = {"Id", "Status Lahan"};
        String query = "select l.id_lahan, s.status from lahan l join status_tanam s on (l.id_status_tanam=s.id_status_tanam) "
                + "where s.id_status_tanam BETWEEN 6 AND 8 order by l.id_lahan ASC ";
        return getDataTabel(kolom, query);
    }

    public double get_nRHC(String id) throws SQLException {
        String query = "select nilai_rhc_Lahan from lahan where id_lahan = " + id;
        return getDataDouble(query);
    }

    public double get_nRHB(String id) throws SQLException {
        String query = "select nilai_rhb_Lahan from lahan where id_lahan = " + id;
        return getDataDouble(query);
    }

    public int get_nSuhu(String id) throws SQLException {
        String query = "select Temperatur_suhu from lahan where id_lahan = " + id;
        return getDataInt(query);
    }

    public int get_nCHujan(String id) throws SQLException {
        String query = "select Curah_hujan from lahan where id_lahan = " + id;
        return getDataInt(query);
    }

    public String get_nTanah(String id) throws SQLException {
        String query = "select Tekstur_tanah from lahan where id_lahan = " + id;
        return getDataString(query);
    }

    public String get_nDrainase(String id) throws SQLException {
        String query = "select Drainase_lahan from lahan where id_lahan = " + id;
        return getDataString(query);
    }

    public int get_nKetinggian(String id) throws SQLException {
        String query = "select Ketinggian_lahan from lahan where id_lahan = " + id;
        return getDataInt(query);
    }

    public String get_nErosi(String id) throws SQLException {
        String query = "select Resiko_erosi from lahan where id_lahan = " + id;
        return getDataString(query);
    }

    public int get_nLereng(String id) throws SQLException {
        String query = "select Lereng from lahan where id_lahan = " + id;
        return getDataInt(query);
    }

    public int get_KetRobusta() throws SQLException {
        String query = "select COUNT(l.id_status_tanam) from lahan l join status_tanam st on "
                + "(l.id_status_tanam=st.id_status_tanam) where st.id_status_tanam = 1 ";
        return getDataInt(query);
    }

    public int get_KetArabica() throws SQLException {
        String query = "select COUNT(l.id_status_tanam) from lahan l join status_tanam st on "
                + "(l.id_status_tanam=st.id_status_tanam) where st.id_status_tanam = 2 ";
        return getDataInt(query);
    }

    public int get_KetLiberica() throws SQLException {
        String query = "select COUNT(l.id_status_tanam) from lahan l join status_tanam st on "
                + "(l.id_status_tanam=st.id_status_tanam) where st.id_status_tanam = 3 ";
        return getDataInt(query);
    }

    public int get_KetPanen() throws SQLException {
        String query = "select COUNT(l.id_status_tanam) from lahan l join status_tanam st on "
                + "(l.id_status_tanam=st.id_status_tanam) where st.id_status_tanam = 4 ";
        return getDataInt(query);
    }

    public int get_KetPemulihan() throws SQLException {
        String query = "select COUNT(l.id_status_tanam) from lahan l join status_tanam st on "
                + "(l.id_status_tanam=st.id_status_tanam) where st.id_status_tanam = 5 ";
        return getDataInt(query);
    }

}
