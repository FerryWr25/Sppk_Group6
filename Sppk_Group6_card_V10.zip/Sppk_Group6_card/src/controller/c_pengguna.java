package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.m_pengguna;
import views.v_cardKepala;
import views.v_card_PegawaiLahan;
import views.v_login;

public class c_pengguna {

    private v_login is_v_login;
    private m_pengguna is_m;
    private String username;
    int level;
    private v_cardKepala is_vKPL;
    private v_card_PegawaiLahan is_vPGW;

    public c_pengguna(int status) throws SQLException {
        this.username = username;
        if (status == 1) {
            is_v_login = new v_login();
            is_m = new m_pengguna();
            is_v_login.setVisible(true);
            is_v_login.getBtn_login().addActionListener(new login_listener());
            is_v_login.getBtn_logout().addActionListener(new logout_Listener());
        } 
    }

    private class login_listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (is_v_login.getField_username().getText().isEmpty() && is_v_login.getField_password().getText().isEmpty()) {
                is_v_login.showMessage("Silahkan lengkapi form");
            } else if (is_v_login.getField_username().getText().isEmpty()) {
                is_v_login.showMessage("Silahkan masukkan username anda");
            } else if (is_v_login.getField_password().getText().isEmpty()) {
                is_v_login.showMessage("Silahkan masukkan password anda");
            } else {
                try {
                    if (is_m.getPengguna(is_v_login.getField_username().getText(), is_v_login.getField_password().getText())) {
                        level = is_m.getlevel(is_v_login.getField_username().getText(), is_v_login.getField_password().getText());
                        if (level == 1) {
                            is_v_login.dispose();
                            new c_akses_Kepala(username);
                        } else {
                            is_v_login.dispose();
                            new c_akses_pegawai(username);
                        }
                    } else {
                        is_v_login.showMessage("Anda tidak terdaftar");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(c_pengguna.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }

    private class logout_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }

    }

}
