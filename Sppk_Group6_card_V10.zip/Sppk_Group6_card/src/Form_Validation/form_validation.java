/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Form_Validation;

import sun.awt.CausedFocusEvent;

/**
 *
 * @author helmets
 */
public class form_validation {

    char number[] = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0'};
    char symbol[] = {'~', '`', '!', '@', '#', '#', '$', '%', '%', '^', '&', '*', '(', ')', '-', '_',
        '+', '=', '[', ']', ',', '{', '}', ':', ';', '"', '?', '/', '.', '>', '<', '|'};
    char huruf[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
        's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
        'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
        'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
    public int cekNumber = 0, cekSymbol = 0, cekHuruf = 0;

    public form_validation() {
        this.cekHuruf = cekHuruf;
        this.cekNumber = cekNumber;
        this.cekSymbol = cekSymbol;
    }

    public int cek_number(String object) {
        char testObject[] = object.toCharArray();
        for (int i = 0; i < testObject.length; i++) {
            for (int j = 0; j < number.length; j++) {
                if (testObject[i] == number[j]) {
                    cekNumber++;
                }
            }
        }
        return cekNumber;
    }

    public int cek_symbol(String object) {
        char testObject2[] = object.toCharArray();
        for (int i = 0; i < testObject2.length; i++) {
            for (int j = 0; j < symbol.length; j++) {
                if (testObject2[i] == symbol[j]) {
                    cekSymbol++;
                }
            }
        }
        return cekSymbol;
    }

    public int cek_huruf(String object) {
        char testObject[] = object.toCharArray();
        for (int i = 0; i < testObject.length; i++) {
            for (int j = 0; j < huruf.length; j++) {
                if (testObject[i] == huruf[j]) {
                    cekHuruf++;
                }
            }
        }
        return cekHuruf;
    }

    public static boolean cek_isNumber(String n) {
        try {
            Integer.parseInt(n);
            return true;
        } catch (NumberFormatException fer) {
            return false;
        }
    }

    public int getCekHUruf() {
        return cekHuruf;
    }

    public int getCekNumber() {
        return cekNumber;
    }

    public int getCekSymbol() {
        return cekSymbol;
    }

}
