package sppk_group6;

import controller.c_akses_Kepala;
import controller.c_akses_pegawai;
import controller.c_pengguna;
import java.sql.SQLException;

public class Sppk_Group6 {

    public static void main(String[] args) throws SQLException {
        new c_pengguna(1);
    }

}
