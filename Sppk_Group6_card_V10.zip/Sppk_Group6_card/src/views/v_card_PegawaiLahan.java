/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import java.awt.Frame;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableModel;

/**
 *
 * @author helmets
 */
public class v_card_PegawaiLahan extends javax.swing.JFrame {

    private JFrame fer = new JFrame();
    private ImageIcon option;

    public v_card_PegawaiLahan() {
        initComponents();
        this.setLocationRelativeTo(this);
        this.option = new ImageIcon(getClass().getResource("/image/option.png"));
    }

    public JPanel getPanel_verifikasi_Tanam() {
        return panel_verifikasiTanam;
    }

    public JButton getBtn_verifikasiLahan() {
        return btn_verifikasiLahan;
    }

    public JButton getBtn_dashboard() {
        return btn_dashboard;
    }

    public JButton getBtn_dataLahan() {
        return btn_dataLahan;
    }

    public JButton getBtn_logout() {
        return btn_logout;
    }

    public JButton getBtn_minimize() {
        return btn_minimize;
    }

    public JPanel getPanel_content() {
        return panel_content;
    }

    public JPanel getPanel_dashboard() {
        return panel_dashboard;
    }

    public JPanel getPanel_dataLahan() {
        return panel_dataLahan;
    }

    public JPanel getPanel_footer() {
        return panel_footer;
    }

    public JPanel getPanel_header() {
        return panel_header;
    }

    public JPanel getPanel_sideBar() {
        return panel_sideBar;
    }

    public void shoeMessage(String pesan) {
        JOptionPane.showMessageDialog(this, pesan);
    }

    public int showOption(String pesan) {
        return JOptionPane.showConfirmDialog(this, pesan, null, JOptionPane.YES_NO_OPTION);
    }

    public JPanel getPanelContainerLahan() {
        return panelContainerLahan;
    }

    public JPanel getPanel_sub_Liberica() {
        return panel_sub_Liberica;
    }

    public JPanel getPanel_sub_arabica() {
        return panel_sub_arabica;
    }

    public JPanel getPanel_sub_lahan() {
        return panel_sub_lahan;
    }

    public JPanel getPanel_sub_robusta() {
        return panel_sub_robusta;
    }

    public JButton getBtn_subArabica() {
        return btn_subArabica;
    }

    public JButton getBtn_subLahan() {
        return btn_subLahan;
    }

    public JButton getBtn_subLiberica() {
        return btn_subLiberica;
    }

    public JButton getBtn_subRobusta() {
        return btn_subRobusta;
    }

    public void minimize() {
        this.setState(Frame.ICONIFIED);
    }

    public void getTableLahan(DefaultTableModel table) {
        tableLahan.setModel(table);
    }

    public void getTable_VerifiedLahan(DefaultTableModel table) {
        tabel_verifiedLahan.setModel(table);
    }

    public void getTableRobusta(DefaultTableModel table) {
        tabelRobusta.setModel(table);
    }

    public void getTableArabica(DefaultTableModel table) {
        tabel_arabica.setModel(table);
    }

    public void getTableLiberica(DefaultTableModel table) {
        tabel_liberica.setModel(table);
    }

    public JButton getBtn_addLahan() {
        return btn_addLahan;
    }

    public JLabel getLabelArabica() {
        return labelArabica;
    }

    public JLabel getLabelLiberica() {
        return labelLiberica;
    }

    public JLabel getLabelRobusta() {
        return labelRobusta;
    }

    public String showMessage_Add(String pesan) {
        return JOptionPane.showInputDialog(pesan);
    }
    String optionLahan[] = {"halus", "agak halus", "kasar"};
    String Drainase[] = {"Baik", "Sedikit terhambat", "terhambat"};
    String erosi[] = {"Rendah", "Cukup tinggi", "tinggi"};
    String statusLahan1[] = {"Fase Panen Robusta", "Fase Pemulihan"};
    String statusLahan2[] = {"Fase Panen Arabica", "Fase Pemulihan"};
    String statusLahan3[] = {"Fase Panen Liberica", "Fase Pemulihan"};
    String statusLahan11[] = {"Fase Pemulihan"};
    String statusLahanVerified[] = {"Fase tanam Robusta", "Fase tanam Arabica", "Fase tanam Liberica"};

    public String showMessageOPtion_Add(String pesan) {
        String data;
        data = (String) JOptionPane.showInputDialog(this, null, pesan, JOptionPane.WARNING_MESSAGE, option, optionLahan, optionLahan[0]);
        return data;
    }

    public String showMessageOption_VerifiedLahan(String pesan) {
        return (String) JOptionPane.showInputDialog(this, null, pesan, JOptionPane.WARNING_MESSAGE, option, statusLahanVerified, statusLahanVerified[0]);
    }

    public String showMessageOption_statusLahan1(String pesan) {
        return (String) JOptionPane.showInputDialog(this, null, pesan, JOptionPane.WARNING_MESSAGE, option, statusLahan1, statusLahan1[0]);
    }
    public String showMessageOption_statusLahan2(String pesan) {
        return (String) JOptionPane.showInputDialog(this, null, pesan, JOptionPane.WARNING_MESSAGE, option, statusLahan2, statusLahan2[0]);
    }
    public String showMessageOption_statusLahan3(String pesan) {
        return (String) JOptionPane.showInputDialog(this, null, pesan, JOptionPane.WARNING_MESSAGE, option, statusLahan3, statusLahan3[0]);
    }
    public String showMessageOption_statusLahan11(String pesan) {
        return (String) JOptionPane.showInputDialog(this, null, pesan, JOptionPane.WARNING_MESSAGE, option, statusLahan11, statusLahan11[0]);
    }

    public String showMessageOption_drainase(String pesan) {
        return (String) JOptionPane.showInputDialog(this, null, pesan, JOptionPane.WARNING_MESSAGE, option, Drainase, Drainase[0]);
    }

    public String showMessageOption_eroSi(String pesan) {
        return (String) JOptionPane.showInputDialog(this, null, pesan, JOptionPane.WARNING_MESSAGE, option, erosi, erosi[0]);
    }

    public int getSelected_Robusta() {
        return this.tabelRobusta.getSelectedRow();
    }

    public String getTableID_Robusta() {
        return tabelRobusta.getValueAt(getSelected_Robusta(), 0).toString();
    }
    public int getSelected_Arabica() {
        return this.tabel_arabica.getSelectedRow();
    }

    public String getTableID_Arabica() {
        return tabel_arabica.getValueAt(getSelected_Arabica(), 0).toString();
    }
    public int getSelected_Liberica() {
        return this.tabel_liberica.getSelectedRow();
    }

    public String getTableID_Liberica() {
        return tabel_liberica.getValueAt(getSelected_Liberica(), 0).toString();
    }

    public String tampilkanPesan_edit(String pesan, String isi) {
        return JOptionPane.showInputDialog(this, pesan, isi);
    }

    public String showMessageOPtion_Edit(String dataChange, String pesan) {
        String data;
        data = (String) JOptionPane.showInputDialog(this, "Masukkan Perubahan data " + dataChange, pesan);
        return data;
    }
    public JTable getTabel_verifiedLahan() {
        return tabel_verifiedLahan;
    }

    public JTable getTableLahan() {
        return tableLahan;
    }

    public int getSelected_Lahan() {
        return this.tableLahan.getSelectedRow();
    }

    public int getSelectVerifiedLahan() {
        return this.tabel_verifiedLahan.getSelectedRow();
    }

    public String getId_TableVerifiedLahan() {
        return tabel_verifiedLahan.getValueAt(getSelectVerifiedLahan(), 0).toString();
    }

    public String getTableID_Lahan() {
        return tableLahan.getValueAt(getSelected_Lahan(), 0).toString();
    }

    public JTextField getField_cariArabica() {
        return field_cariArabica;
    }

    public JTextField getField_cariLiberica() {
        return field_cariLiberica;
    }

    public JTextField getField_cariRobusta() {
        return field_cariRobusta;
    }

    public JTextField getField_cariLahan() {
        return field_cariLahan;
    }

    public JTable getTabelRobusta() {
        return tabelRobusta;
    }

    public JTable getTabel_arabica() {
        return tabel_arabica;
    }

    public JTable getTabel_liberica() {
        return tabel_liberica;
    }
    
    
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel9 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        panel_header = new javax.swing.JPanel();
        btn_minimize = new javax.swing.JButton();
        btn_logout = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        panel_sideBar = new javax.swing.JPanel();
        btn_dataLahan = new javax.swing.JButton();
        btn_dashboard = new javax.swing.JButton();
        btn_verifikasiLahan = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        panel_content = new javax.swing.JPanel();
        panel_dashboard = new javax.swing.JPanel();
        labelArabica = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        labelRobusta = new javax.swing.JLabel();
        labelLiberica = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        panel_dataLahan = new javax.swing.JPanel();
        btn_subRobusta = new javax.swing.JButton();
        btn_subArabica = new javax.swing.JButton();
        btn_subLiberica = new javax.swing.JButton();
        btn_subLahan = new javax.swing.JButton();
        panelContainerLahan = new javax.swing.JPanel();
        panel_sub_lahan = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableLahan = new javax.swing.JTable();
        field_cariLahan = new javax.swing.JTextField();
        jSeparator4 = new javax.swing.JSeparator();
        btn_addLahan = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        panel_sub_robusta = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabelRobusta = new javax.swing.JTable();
        field_cariRobusta = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel17 = new javax.swing.JLabel();
        panel_sub_arabica = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabel_arabica = new javax.swing.JTable();
        field_cariArabica = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel8 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        panel_sub_Liberica = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tabel_liberica = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();
        field_cariLiberica = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        panel_verifikasiTanam = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tabel_verifiedLahan = new javax.swing.JTable();
        panel_footer = new javax.swing.JPanel();

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/contentLahan_Pegawai.png"))); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 153, 255));
        setUndecorated(true);

        jPanel1.setMinimumSize(new java.awt.Dimension(1280, 720));
        jPanel1.setPreferredSize(new java.awt.Dimension(1270, 720));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panel_header.setBackground(new java.awt.Color(255, 255, 255));
        panel_header.setOpaque(false);
        panel_header.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_minimize.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/min1.png"))); // NOI18N
        btn_minimize.setBorder(null);
        btn_minimize.setBorderPainted(false);
        btn_minimize.setContentAreaFilled(false);
        btn_minimize.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_minimize.setFocusPainted(false);
        btn_minimize.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/min11.png"))); // NOI18N
        panel_header.add(btn_minimize, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 20, 40, 40));

        btn_logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/logg1.png"))); // NOI18N
        btn_logout.setBorder(null);
        btn_logout.setBorderPainted(false);
        btn_logout.setContentAreaFilled(false);
        btn_logout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_logout.setFocusPainted(false);
        btn_logout.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/logg11.png"))); // NOI18N
        panel_header.add(btn_logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1220, 20, 40, 40));

        jLabel2.setBackground(new java.awt.Color(239, 222, 241));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/headerPakek.png"))); // NOI18N
        jLabel2.setOpaque(true);
        panel_header.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 0, 970, 90));

        jPanel1.add(panel_header, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, -1));

        panel_sideBar.setBackground(new java.awt.Color(255, 255, 255));
        panel_sideBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_dataLahan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/unnactiveLahan.png"))); // NOI18N
        btn_dataLahan.setBorder(null);
        btn_dataLahan.setBorderPainted(false);
        btn_dataLahan.setContentAreaFilled(false);
        btn_dataLahan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_dataLahan.setFocusPainted(false);
        btn_dataLahan.setName("lahan"); // NOI18N
        panel_sideBar.add(btn_dataLahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, 280, 50));

        btn_dashboard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/unnactiveDashboard.png"))); // NOI18N
        btn_dashboard.setBorder(null);
        btn_dashboard.setBorderPainted(false);
        btn_dashboard.setContentAreaFilled(false);
        btn_dashboard.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_dashboard.setFocusPainted(false);
        btn_dashboard.setName("dashboard"); // NOI18N
        panel_sideBar.add(btn_dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 280, 60));

        btn_verifikasiLahan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/vrikasiLahan_unnActive.png"))); // NOI18N
        btn_verifikasiLahan.setBorderPainted(false);
        btn_verifikasiLahan.setContentAreaFilled(false);
        btn_verifikasiLahan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_verifikasiLahan.setFocusPainted(false);
        panel_sideBar.add(btn_verifikasiLahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 430, 290, 50));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/sidebarLagi.png"))); // NOI18N
        panel_sideBar.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 300, 720));

        jPanel1.add(panel_sideBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 300, 730));

        panel_content.setLayout(new java.awt.CardLayout());

        panel_dashboard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelArabica.setForeground(new java.awt.Color(153, 153, 153));
        labelArabica.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelArabica.setText("lahan ini merupakan........");
        panel_dashboard.add(labelArabica, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 200, 210, 40));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/ezgif.com-gif-maker.gif"))); // NOI18N
        panel_dashboard.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 300, 850, 250));

        labelRobusta.setForeground(new java.awt.Color(153, 153, 153));
        labelRobusta.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelRobusta.setText("lahan ini merupakan........");
        panel_dashboard.add(labelRobusta, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 210, 210, 30));

        labelLiberica.setForeground(new java.awt.Color(153, 153, 153));
        labelLiberica.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelLiberica.setText("lahan ini merupakan........");
        panel_dashboard.add(labelLiberica, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 200, 210, 40));

        jLabel4.setBackground(new java.awt.Color(239, 222, 241));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/dashboardContent.png"))); // NOI18N
        jLabel4.setOpaque(true);
        panel_dashboard.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 970, 610));

        panel_content.add(panel_dashboard, "card2");

        panel_dataLahan.setBackground(new java.awt.Color(239, 222, 241));
        panel_dataLahan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_subRobusta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnRobusta1.png"))); // NOI18N
        btn_subRobusta.setBorderPainted(false);
        btn_subRobusta.setContentAreaFilled(false);
        btn_subRobusta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_subRobusta.setFocusPainted(false);
        btn_subRobusta.setRequestFocusEnabled(false);
        btn_subRobusta.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnRobusta2.png"))); // NOI18N
        btn_subRobusta.setVerifyInputWhenFocusTarget(false);
        panel_dataLahan.add(btn_subRobusta, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 240, 160));

        btn_subArabica.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnArabica1.png"))); // NOI18N
        btn_subArabica.setBorderPainted(false);
        btn_subArabica.setContentAreaFilled(false);
        btn_subArabica.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_subArabica.setFocusPainted(false);
        btn_subArabica.setRequestFocusEnabled(false);
        btn_subArabica.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnArabica2.png"))); // NOI18N
        btn_subArabica.setVerifyInputWhenFocusTarget(false);
        panel_dataLahan.add(btn_subArabica, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 0, 240, 160));

        btn_subLiberica.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnLiberica1.png"))); // NOI18N
        btn_subLiberica.setBorderPainted(false);
        btn_subLiberica.setContentAreaFilled(false);
        btn_subLiberica.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_subLiberica.setFocusPainted(false);
        btn_subLiberica.setRequestFocusEnabled(false);
        btn_subLiberica.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnLiberica2.png"))); // NOI18N
        btn_subLiberica.setVerifyInputWhenFocusTarget(false);
        panel_dataLahan.add(btn_subLiberica, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 0, 240, 160));

        btn_subLahan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnLahan1.png"))); // NOI18N
        btn_subLahan.setBorderPainted(false);
        btn_subLahan.setContentAreaFilled(false);
        btn_subLahan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_subLahan.setFocusPainted(false);
        btn_subLahan.setRequestFocusEnabled(false);
        btn_subLahan.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnLahan2.png"))); // NOI18N
        btn_subLahan.setVerifyInputWhenFocusTarget(false);
        panel_dataLahan.add(btn_subLahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 240, 160));

        panelContainerLahan.setLayout(new java.awt.CardLayout());

        panel_sub_lahan.setBackground(new java.awt.Color(239, 222, 241));
        panel_sub_lahan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tableLahan.setFont(new java.awt.Font("Calibri", 0, 12));
        tableLahan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tableLahan.setToolTipText("Silahkan pilih baris data pada table, jika anda akan mengubah data lahan");
        tableLahan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tableLahan.setGridColor(new java.awt.Color(153, 153, 153));
        tableLahan.setSelectionBackground(new java.awt.Color(204, 204, 204));
        tableLahan.setSurrendersFocusOnKeystroke(true);
        jScrollPane1.setViewportView(tableLahan);

        panel_sub_lahan.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, 860, 290));

        field_cariLahan.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        field_cariLahan.setBorder(null);
        field_cariLahan.setOpaque(false);
        panel_sub_lahan.add(field_cariLahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 50, 140, 30));
        panel_sub_lahan.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 80, 140, 10));

        btn_addLahan.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        btn_addLahan.setText("Tambah lahan+");
        panel_sub_lahan.add(btn_addLahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, 130, 30));

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/contentLahan_Pegawai.png"))); // NOI18N
        panel_sub_lahan.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 910, 370));

        jLabel18.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel18.setText("Cari data");
        panel_sub_lahan.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 50, 70, 30));

        panelContainerLahan.add(panel_sub_lahan, "card3");

        panel_sub_robusta.setBackground(new java.awt.Color(239, 222, 241));
        panel_sub_robusta.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tabelRobusta.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        tabelRobusta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabelRobusta.setToolTipText("Silahkan pilih data pada table, jika akan mengubah status lahan");
        tabelRobusta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jScrollPane2.setViewportView(tabelRobusta);

        panel_sub_robusta.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 770, 270));

        field_cariRobusta.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        field_cariRobusta.setBorder(null);
        field_cariRobusta.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        field_cariRobusta.setOpaque(false);
        panel_sub_robusta.add(field_cariRobusta, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 60, 140, 30));

        jLabel10.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel10.setText("Data Lahan Penanaman Kopi ROBUSTA");
        panel_sub_robusta.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 250, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/contentLahan_Pegawai.png"))); // NOI18N
        panel_sub_robusta.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 910, 360));
        panel_sub_robusta.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 90, 140, 10));

        jLabel17.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel17.setText("Cari data");
        panel_sub_robusta.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 60, 70, 30));

        panelContainerLahan.add(panel_sub_robusta, "card3");

        panel_sub_arabica.setBackground(new java.awt.Color(239, 222, 241));
        panel_sub_arabica.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tabel_arabica.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        tabel_arabica.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabel_arabica.setToolTipText("Silahkan pilih data pada table, jika akan mengubah status lahan");
        tabel_arabica.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jScrollPane3.setViewportView(tabel_arabica);

        panel_sub_arabica.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 780, 260));

        field_cariArabica.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        field_cariArabica.setBorder(null);
        field_cariArabica.setOpaque(false);
        field_cariArabica.setScrollOffset(1);
        field_cariArabica.setSelectionEnd(1);
        field_cariArabica.setSelectionStart(1);
        panel_sub_arabica.add(field_cariArabica, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 40, 140, 30));
        panel_sub_arabica.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 70, 140, 10));

        jLabel8.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel8.setText("Cari data");
        panel_sub_arabica.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 47, 70, 30));

        jLabel13.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel13.setText("Data Lahan Penanaman Kopi ARABICA");
        panel_sub_arabica.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 490, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/contentLahan_Pegawai.png"))); // NOI18N
        panel_sub_arabica.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 900, 360));

        panelContainerLahan.add(panel_sub_arabica, "card3");

        panel_sub_Liberica.setBackground(new java.awt.Color(239, 222, 241));
        panel_sub_Liberica.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tabel_liberica.setFont(new java.awt.Font("Calibri", 0, 12));
        tabel_liberica.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabel_liberica.setToolTipText("Silahkan pilih data pada table, jika akan mengubah status lahan");
        tabel_liberica.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jScrollPane4.setViewportView(tabel_liberica);

        panel_sub_Liberica.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 800, 260));

        jLabel11.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel11.setText("Data Lahan Penanaman Kopi LIBERICA");
        panel_sub_Liberica.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 240, -1));

        field_cariLiberica.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        field_cariLiberica.setBorder(null);
        field_cariLiberica.setOpaque(false);
        panel_sub_Liberica.add(field_cariLiberica, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 50, 140, 30));
        panel_sub_Liberica.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 80, 140, 10));

        jLabel15.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel15.setText("Cari data");
        panel_sub_Liberica.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 60, 70, 30));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/contentLahan_Pegawai.png"))); // NOI18N
        panel_sub_Liberica.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 900, 360));

        panelContainerLahan.add(panel_sub_Liberica, "card3");

        panel_dataLahan.add(panelContainerLahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 920, 410));

        panel_content.add(panel_dataLahan, "card2");

        panel_verifikasiTanam.setBackground(new java.awt.Color(239, 222, 241));
        panel_verifikasiTanam.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tabel_verifiedLahan.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        tabel_verifiedLahan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabel_verifiedLahan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jScrollPane5.setViewportView(tabel_verifiedLahan);

        panel_verifikasiTanam.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, -1, -1));

        panel_content.add(panel_verifikasiTanam, "card2");

        jPanel1.add(panel_content, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 90, 970, 610));

        panel_footer.setBackground(new java.awt.Color(239, 222, 241));
        panel_footer.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(panel_footer, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 700, 1050, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(v_card_PegawaiLahan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(v_card_PegawaiLahan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(v_card_PegawaiLahan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(v_card_PegawaiLahan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new v_card_PegawaiLahan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_addLahan;
    private javax.swing.JButton btn_dashboard;
    private javax.swing.JButton btn_dataLahan;
    private javax.swing.JButton btn_logout;
    private javax.swing.JButton btn_minimize;
    private javax.swing.JButton btn_subArabica;
    private javax.swing.JButton btn_subLahan;
    private javax.swing.JButton btn_subLiberica;
    private javax.swing.JButton btn_subRobusta;
    private javax.swing.JButton btn_verifikasiLahan;
    private javax.swing.JTextField field_cariArabica;
    private javax.swing.JTextField field_cariLahan;
    private javax.swing.JTextField field_cariLiberica;
    private javax.swing.JTextField field_cariRobusta;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JLabel labelArabica;
    private javax.swing.JLabel labelLiberica;
    private javax.swing.JLabel labelRobusta;
    private javax.swing.JPanel panelContainerLahan;
    private javax.swing.JPanel panel_content;
    private javax.swing.JPanel panel_dashboard;
    private javax.swing.JPanel panel_dataLahan;
    private javax.swing.JPanel panel_footer;
    private javax.swing.JPanel panel_header;
    private javax.swing.JPanel panel_sideBar;
    private javax.swing.JPanel panel_sub_Liberica;
    private javax.swing.JPanel panel_sub_arabica;
    private javax.swing.JPanel panel_sub_lahan;
    private javax.swing.JPanel panel_sub_robusta;
    private javax.swing.JPanel panel_verifikasiTanam;
    private javax.swing.JTable tabelRobusta;
    private javax.swing.JTable tabel_arabica;
    private javax.swing.JTable tabel_liberica;
    private javax.swing.JTable tabel_verifiedLahan;
    javax.swing.JTable tableLahan;
    // End of variables declaration//GEN-END:variables
}
