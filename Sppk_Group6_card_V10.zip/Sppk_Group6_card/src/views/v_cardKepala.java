package views;

import java.awt.Frame;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class v_cardKepala extends javax.swing.JFrame {

    public v_cardKepala() {
        initComponents();
        this.setLocationRelativeTo(this);
    }

    public JButton getBtn_batal_arabica() {
        return btn_batal_arabica;
    }

    public JButton getBtn_batalLiberica() {
        return btn_batalLiberica;
    }

    public JButton getBtn_batalRobusta() {
        return btn_batalRobusta;
    }

    public JButton getBtn_recomendasikan_arabica() {
        return btn_recomendasikan_arabica;
    }

    public JButton getBtn_recomendasikan_liberica() {
        return btn_recomendasikan_liberica;
    }

    public JButton getBtn_recomendasikan_robusta() {
        return btn_recomendasikan_robusta;
    }

    public JLabel getLabelinformasi_ara1() {
        return labelinformasi_ara1;
    }

    public JLabel getLabelinformasi_ara2() {
        return labelinformasi_ara2;
    }

    public JLabel getLabelinformasi_ara3() {
        return labelinformasi_ara3;
    }

    public JLabel getLabelinformasi_libe1() {
        return labelinformasi_libe1;
    }

    public JLabel getLabelinformasi_libe2() {
        return labelinformasi_libe2;
    }

    public JLabel getLabelinformasi_libe3() {
        return labelinformasi_libe3;
    }

    public JLabel getLabelinformasi_robu1() {
        return labelinformasi_robu1;
    }

    public JLabel getLabelinformasi_robu2() {
        return labelinformasi_robu2;
    }

    public JLabel getLabelinformasi_robu3() {
        return labelinformasi_robu3;
    }
    

    public JButton getBtn_DashArabica() {
        return btn_DashArabica;
    }

    public JButton getBtn_DashLiberica() {
        return btn_DashLiberica;
    }

    public JButton getBtn_DashPanen() {
        return btn_DashPanen;
    }

    public JButton getBtn_DashPemulihan() {
        return btn_DashPemulihan;
    }

    public JButton getBtn_Dashrobusta() {
        return btn_Dashrobusta;
    }
    
    public JLabel getLabelKeteranganMasaPanen() {
        return labelKeteranganMasaPanen;
    }

    public JLabel getLabelKeteranganPemulihan() {
        return labelKeteranganPemulihan;
    }

    public JLabel getLabelKeteranganArabica() {
        return labelKeteranganArabica;
    }

    public JLabel getLabelKeteranganLiberica() {
        return labelKeteranganLiberica;
    }

    public JLabel getLabelKeteranganRobusta() {
        return labelKeteranganRobusta;
    }
    
    public JLabel getLabelHasil() {
        return labelHasil;
    }

    public JButton getBtnAnalisis_robusta() {
        return btnAnalisis_robusta;
    }

    public JComboBox getCombo_idLahan() {
        return combo_idLahan;
    }

    public void minimize() {
        this.setState(Frame.ICONIFIED);
    }

    public void showMessage(String pesan) {
        JOptionPane.showMessageDialog(this, pesan);
    }

    public int showOption(String pesan) {
        return JOptionPane.showConfirmDialog(this, pesan, null, JOptionPane.YES_NO_OPTION);
    }

    public JButton getBtn_Liberica() {
        return btn_Liberica;
    }

    public JButton getBtn_arabica() {
        return btn_arabica;
    }

    public JButton getBtn_dashboard() {
        return btn_dashboard;
    }

    public JButton getBtn_dataLahan() {
        return btn_dataLahan;
    }

    public JButton getBtn_logout() {
        return btn_logout;
    }

    public JButton getBtn_minimize() {
        return btn_minimize;
    }

    public JButton getBtn_robusta() {
        return btn_robusta;
    }

    public JPanel getPanel_arabica() {
        return panel_arabica;
    }

    public JPanel getPanel_content() {
        return panel_content;
    }

    public JPanel getPanel_dashboard() {
        return panel_dashboard;
    }

    public JPanel getPanel_dataLahan() {
        return panel_dataLahan;
    }

    public JPanel getPanel_header() {
        return panel_header;
    }

    public JPanel getPanel_liberica() {
        return panel_liberica;
    }

    public JPanel getPanel_robusta() {
        return panel_robusta;
    }

    public JPanel getPanel_sideBar() {
        return panel_sideBar;
    }

    public JLabel getLabel_TTanah() {
        return label_TTanah;
    }

    public JLabel getLabel_curahHujan() {
        return label_curahHujan;
    }

    public JLabel getLabel_drainase() {
        return label_drainase;
    }

    public JLabel getLabel_erosi() {
        return label_erosi;
    }

    public JLabel getLabel_ketinggian() {
        return label_ketinggian;
    }

    public JLabel getLabel_lereng() {
        return label_lereng;
    }

    public JLabel getLabel_rhb() {
        return label_rhb;
    }

    public JLabel getLabel_rhc() {
        return label_rhc;
    }

    public JLabel getLabel_suhu() {
        return label_suhu;
    }
//    card arabica

    public JComboBox<String> getCombo_idLahan1() {
        return combo_idLahanArabica;
    }

    public JLabel getLabel_TTanah1() {
        return label_TTanah1;
    }

    public JLabel getLabel_curahHujan1() {
        return label_curahHujan1;
    }

    public JLabel getLabel_drainase1() {
        return label_drainase1;
    }

    public JLabel getLabel_erosi1() {
        return label_erosi1;
    }

    public JLabel getLabel_ketinggian1() {
        return label_ketinggian1;
    }

    public JLabel getLabel_lereng1() {
        return label_lereng1;
    }

    public JLabel getLabel_rhb1() {
        return label_rhb1;
    }

    public JLabel getLabel_rhc1() {
        return label_rhc1;
    }

    public JLabel getLabel_suhu1() {
        return label_suhu1;
    }

    public JButton getBtnAnalisis_arabica() {
        return btnAnalisis_arabica;
    }

    public JLabel getLabelHasil_arabica() {
        return labelHasil_arabica;
    }

    public JComboBox getCombo_idLahanArabica() {
        return combo_idLahanArabica;
    }

//    content liberica 
    public JButton getBtnAnalisis_Liberica() {
        return btnAnalisis_Liberica;
    }

    public JComboBox getCombo_idLahanLiberica() {
        return combo_idLahanLiberica;
    }

    public JLabel getLabelHasilLiberica() {
        return labelHasilLiberica;
    }

    public JLabel getLabel_TTanah2() {
        return label_TTanah2;
    }

    public JLabel getLabel_curahHujan2() {
        return label_curahHujan2;
    }

    public JLabel getLabel_drainase2() {
        return label_drainase2;
    }

    public JLabel getLabel_erosi2() {
        return label_erosi2;
    }

    public JLabel getLabel_ketinggian2() {
        return label_ketinggian2;
    }

    public JLabel getLabel_lereng2() {
        return label_lereng2;
    }

    public JLabel getLabel_rhb2() {
        return label_rhb2;
    }

    public JLabel getLabel_rhc2() {
        return label_rhc2;
    }

    public JLabel getLabel_suhu2() {
        return label_suhu2;
    }

    public JTextField getField_cariLahan() {
        return field_cariLahan;
    }
    

    //content lahan
    public void getTableLahan(DefaultTableModel table) {
        tableLahan.setModel(table);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        panel_header = new javax.swing.JPanel();
        btn_minimize = new javax.swing.JButton();
        btn_logout = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        panel_sideBar = new javax.swing.JPanel();
        btn_dataLahan = new javax.swing.JButton();
        btn_Liberica = new javax.swing.JButton();
        btn_arabica = new javax.swing.JButton();
        btn_robusta = new javax.swing.JButton();
        btn_dashboard = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        panel_content = new javax.swing.JPanel();
        panel_robusta = new javax.swing.JPanel();
        label_rhb = new javax.swing.JLabel();
        label_rhc = new javax.swing.JLabel();
        label_suhu = new javax.swing.JLabel();
        label_curahHujan = new javax.swing.JLabel();
        label_TTanah = new javax.swing.JLabel();
        label_drainase = new javax.swing.JLabel();
        label_ketinggian = new javax.swing.JLabel();
        label_erosi = new javax.swing.JLabel();
        label_lereng = new javax.swing.JLabel();
        btnAnalisis_robusta = new javax.swing.JButton();
        combo_idLahan = new javax.swing.JComboBox<>();
        labelHasil = new javax.swing.JLabel();
        labelinformasi_robu3 = new javax.swing.JLabel();
        labelinformasi_robu1 = new javax.swing.JLabel();
        labelinformasi_robu2 = new javax.swing.JLabel();
        btn_batalRobusta = new javax.swing.JButton();
        btn_recomendasikan_robusta = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        panel_arabica = new javax.swing.JPanel();
        label_lereng1 = new javax.swing.JLabel();
        label_rhb1 = new javax.swing.JLabel();
        label_rhc1 = new javax.swing.JLabel();
        label_suhu1 = new javax.swing.JLabel();
        label_curahHujan1 = new javax.swing.JLabel();
        label_TTanah1 = new javax.swing.JLabel();
        label_drainase1 = new javax.swing.JLabel();
        label_ketinggian1 = new javax.swing.JLabel();
        label_erosi1 = new javax.swing.JLabel();
        labelHasil_arabica = new javax.swing.JLabel();
        btnAnalisis_arabica = new javax.swing.JButton();
        combo_idLahanArabica = new javax.swing.JComboBox<>();
        labelinformasi_ara1 = new javax.swing.JLabel();
        labelinformasi_ara2 = new javax.swing.JLabel();
        labelinformasi_ara3 = new javax.swing.JLabel();
        btn_batal_arabica = new javax.swing.JButton();
        btn_recomendasikan_arabica = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        panel_liberica = new javax.swing.JPanel();
        label_lereng2 = new javax.swing.JLabel();
        label_rhb2 = new javax.swing.JLabel();
        label_rhc2 = new javax.swing.JLabel();
        label_suhu2 = new javax.swing.JLabel();
        label_curahHujan2 = new javax.swing.JLabel();
        label_TTanah2 = new javax.swing.JLabel();
        label_drainase2 = new javax.swing.JLabel();
        label_ketinggian2 = new javax.swing.JLabel();
        label_erosi2 = new javax.swing.JLabel();
        labelHasilLiberica = new javax.swing.JLabel();
        btnAnalisis_Liberica = new javax.swing.JButton();
        combo_idLahanLiberica = new javax.swing.JComboBox<>();
        labelinformasi_libe3 = new javax.swing.JLabel();
        labelinformasi_libe2 = new javax.swing.JLabel();
        labelinformasi_libe1 = new javax.swing.JLabel();
        btn_batalLiberica = new javax.swing.JButton();
        btn_recomendasikan_liberica = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        panel_dataLahan = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableLahan = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        field_cariLahan = new javax.swing.JTextField();
        jSeparator4 = new javax.swing.JSeparator();
        panel_dashboard = new javax.swing.JPanel();
        labelKeteranganPemulihan = new javax.swing.JLabel();
        labelKeteranganMasaPanen = new javax.swing.JLabel();
        labelKeteranganArabica = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        labelKeteranganRobusta = new javax.swing.JLabel();
        labelKeteranganLiberica = new javax.swing.JLabel();
        btn_DashLiberica = new javax.swing.JButton();
        btn_DashArabica = new javax.swing.JButton();
        btn_DashPanen = new javax.swing.JButton();
        btn_DashPemulihan = new javax.swing.JButton();
        btn_Dashrobusta = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 153, 255));
        setUndecorated(true);

        jPanel1.setMinimumSize(new java.awt.Dimension(1280, 720));
        jPanel1.setPreferredSize(new java.awt.Dimension(1270, 720));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panel_header.setBackground(new java.awt.Color(255, 255, 255));
        panel_header.setOpaque(false);
        panel_header.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_minimize.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/min1.png"))); // NOI18N
        btn_minimize.setBorder(null);
        btn_minimize.setBorderPainted(false);
        btn_minimize.setContentAreaFilled(false);
        btn_minimize.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_minimize.setFocusPainted(false);
        btn_minimize.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/min11.png"))); // NOI18N
        panel_header.add(btn_minimize, new org.netbeans.lib.awtextra.AbsoluteConstraints(1180, 10, 40, 40));

        btn_logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/logg1.png"))); // NOI18N
        btn_logout.setBorder(null);
        btn_logout.setBorderPainted(false);
        btn_logout.setContentAreaFilled(false);
        btn_logout.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_logout.setFocusPainted(false);
        btn_logout.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/logg11.png"))); // NOI18N
        panel_header.add(btn_logout, new org.netbeans.lib.awtextra.AbsoluteConstraints(1220, 10, 40, 40));

        jLabel2.setBackground(new java.awt.Color(255, 255, 153));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/headerPakek.png"))); // NOI18N
        panel_header.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 0, 970, 80));

        jPanel1.add(panel_header, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, -1));

        panel_sideBar.setBackground(new java.awt.Color(153, 153, 153));
        panel_sideBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_dataLahan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/unnactiveLahan.png"))); // NOI18N
        btn_dataLahan.setBorder(null);
        btn_dataLahan.setBorderPainted(false);
        btn_dataLahan.setContentAreaFilled(false);
        btn_dataLahan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_dataLahan.setFocusPainted(false);
        btn_dataLahan.setName("lahan"); // NOI18N
        btn_dataLahan.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/activeLahan.png"))); // NOI18N
        panel_sideBar.add(btn_dataLahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 540, 280, 50));

        btn_Liberica.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/unnactiveLiberica.png"))); // NOI18N
        btn_Liberica.setBorder(null);
        btn_Liberica.setBorderPainted(false);
        btn_Liberica.setContentAreaFilled(false);
        btn_Liberica.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_Liberica.setFocusPainted(false);
        btn_Liberica.setName("liberica"); // NOI18N
        btn_Liberica.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/activeLiberica.png"))); // NOI18N
        panel_sideBar.add(btn_Liberica, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 490, 280, 50));

        btn_arabica.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/cek.png"))); // NOI18N
        btn_arabica.setBorder(null);
        btn_arabica.setBorderPainted(false);
        btn_arabica.setContentAreaFilled(false);
        btn_arabica.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_arabica.setFocusPainted(false);
        btn_arabica.setName("arabica"); // NOI18N
        btn_arabica.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/activeArabica.png"))); // NOI18N
        panel_sideBar.add(btn_arabica, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 430, 280, 50));

        btn_robusta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/unnactiveRobusta.png"))); // NOI18N
        btn_robusta.setBorder(null);
        btn_robusta.setContentAreaFilled(false);
        btn_robusta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_robusta.setFocusPainted(false);
        btn_robusta.setName("robusta"); // NOI18N
        btn_robusta.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/activeRobusta.png"))); // NOI18N
        panel_sideBar.add(btn_robusta, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, 280, 50));

        btn_dashboard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/unnactiveDashboard.png"))); // NOI18N
        btn_dashboard.setBorder(null);
        btn_dashboard.setBorderPainted(false);
        btn_dashboard.setContentAreaFilled(false);
        btn_dashboard.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_dashboard.setFocusPainted(false);
        btn_dashboard.setName("dashboard"); // NOI18N
        btn_dashboard.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/activeDashboard.png"))); // NOI18N
        panel_sideBar.add(btn_dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 280, 60));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/sidebarLagi.png"))); // NOI18N
        panel_sideBar.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, -1, 740));

        jPanel1.add(panel_sideBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 300, 730));

        panel_content.setLayout(new java.awt.CardLayout());

        panel_robusta.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label_rhb.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        label_rhb.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_robusta.add(label_rhb, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 50, 110, 50));

        label_rhc.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        label_rhc.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_robusta.add(label_rhc, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 120, 110, 40));

        label_suhu.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        label_suhu.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_robusta.add(label_suhu, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 370, 110, 50));

        label_curahHujan.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        label_curahHujan.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_robusta.add(label_curahHujan, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 440, 110, 40));

        label_TTanah.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        label_TTanah.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_robusta.add(label_TTanah, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 480, 110, 40));

        label_drainase.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        label_drainase.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_robusta.add(label_drainase, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 450, 100, 40));

        label_ketinggian.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        label_ketinggian.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_robusta.add(label_ketinggian, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 370, 110, 50));

        label_erosi.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        label_erosi.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_robusta.add(label_erosi, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 110, 40));

        label_lereng.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        label_lereng.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_robusta.add(label_lereng, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, 110, 50));

        btnAnalisis_robusta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnAnalisah2.png"))); // NOI18N
        btnAnalisis_robusta.setBorderPainted(false);
        btnAnalisis_robusta.setContentAreaFilled(false);
        btnAnalisis_robusta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAnalisis_robusta.setFocusPainted(false);
        btnAnalisis_robusta.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnAnalisah1.png"))); // NOI18N
        panel_robusta.add(btnAnalisis_robusta, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 350, 170, 40));

        combo_idLahan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih disini...." }));
        panel_robusta.add(combo_idLahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 230, 150, 30));

        labelHasil.setFont(new java.awt.Font("Agency FB", 1, 24)); // NOI18N
        labelHasil.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_robusta.add(labelHasil, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 450, 160, 60));

        labelinformasi_robu3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelinformasi_robu3.setText("untuk ditanami kopi Robusta");
        panel_robusta.add(labelinformasi_robu3, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 320, 190, 20));

        labelinformasi_robu1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelinformasi_robu1.setText("Klik tombol dibawah ini jika anda");
        panel_robusta.add(labelinformasi_robu1, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 280, 200, 20));

        labelinformasi_robu2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelinformasi_robu2.setText("merekomendasikan lahan ini");
        panel_robusta.add(labelinformasi_robu2, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 300, 210, 20));

        btn_batalRobusta.setText("Batal");
        panel_robusta.add(btn_batalRobusta, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 400, 190, 40));

        btn_recomendasikan_robusta.setText("Recomendasikan");
        panel_robusta.add(btn_recomendasikan_robusta, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 350, 190, 40));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/analisisSppk.png"))); // NOI18N
        panel_robusta.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 970, 560));

        panel_content.add(panel_robusta, "card2");

        panel_arabica.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label_lereng1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_arabica.add(label_lereng1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, 110, 50));

        label_rhb1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_arabica.add(label_rhb1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 50, 110, 50));

        label_rhc1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_arabica.add(label_rhc1, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 120, 110, 40));

        label_suhu1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_arabica.add(label_suhu1, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 370, 110, 50));

        label_curahHujan1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_arabica.add(label_curahHujan1, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 440, 110, 40));

        label_TTanah1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_arabica.add(label_TTanah1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 480, 110, 40));

        label_drainase1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_arabica.add(label_drainase1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 450, 100, 40));

        label_ketinggian1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_arabica.add(label_ketinggian1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 370, 110, 50));

        label_erosi1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_arabica.add(label_erosi1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 110, 40));

        labelHasil_arabica.setFont(new java.awt.Font("Agency FB", 1, 24)); // NOI18N
        labelHasil_arabica.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_arabica.add(labelHasil_arabica, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 450, 160, 60));

        btnAnalisis_arabica.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnAnalisah2.png"))); // NOI18N
        btnAnalisis_arabica.setBorderPainted(false);
        btnAnalisis_arabica.setContentAreaFilled(false);
        btnAnalisis_arabica.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAnalisis_arabica.setFocusPainted(false);
        btnAnalisis_arabica.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnAnalisah1.png"))); // NOI18N
        panel_arabica.add(btnAnalisis_arabica, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 350, 150, 40));

        combo_idLahanArabica.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih disini...." }));
        panel_arabica.add(combo_idLahanArabica, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 240, 160, 30));

        labelinformasi_ara1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelinformasi_ara1.setText("Klik tombol dibawah ini jika anda");
        panel_arabica.add(labelinformasi_ara1, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 280, 240, 20));

        labelinformasi_ara2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelinformasi_ara2.setText("merekomendasikan lahan ini");
        panel_arabica.add(labelinformasi_ara2, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 300, 240, 20));

        labelinformasi_ara3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelinformasi_ara3.setText("untuk ditanami kopi Arabica");
        panel_arabica.add(labelinformasi_ara3, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 320, 240, 20));

        btn_batal_arabica.setText("Batal");
        panel_arabica.add(btn_batal_arabica, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 400, 160, 40));

        btn_recomendasikan_arabica.setText("Recomendasikan");
        panel_arabica.add(btn_recomendasikan_arabica, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 350, 160, 40));

        jLabel13.setBackground(new java.awt.Color(239, 222, 241));
        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/analisisSppk.png"))); // NOI18N
        panel_arabica.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 970, 560));

        panel_content.add(panel_arabica, "card2");

        panel_liberica.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        label_lereng2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_liberica.add(label_lereng2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, 110, 50));

        label_rhb2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_liberica.add(label_rhb2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 50, 110, 50));

        label_rhc2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_liberica.add(label_rhc2, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 120, 110, 40));

        label_suhu2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_liberica.add(label_suhu2, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 370, 110, 50));

        label_curahHujan2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_liberica.add(label_curahHujan2, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 440, 110, 40));

        label_TTanah2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_liberica.add(label_TTanah2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 480, 110, 40));

        label_drainase2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_liberica.add(label_drainase2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 450, 100, 40));

        label_ketinggian2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_liberica.add(label_ketinggian2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 370, 110, 50));

        label_erosi2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_liberica.add(label_erosi2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 110, 40));

        labelHasilLiberica.setFont(new java.awt.Font("Agency FB", 1, 24)); // NOI18N
        labelHasilLiberica.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        panel_liberica.add(labelHasilLiberica, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 450, 160, 60));

        btnAnalisis_Liberica.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnAnalisah2.png"))); // NOI18N
        btnAnalisis_Liberica.setBorderPainted(false);
        btnAnalisis_Liberica.setContentAreaFilled(false);
        btnAnalisis_Liberica.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAnalisis_Liberica.setFocusPainted(false);
        btnAnalisis_Liberica.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/btnAnalisah1.png"))); // NOI18N
        panel_liberica.add(btnAnalisis_Liberica, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 340, 150, 40));

        combo_idLahanLiberica.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih disini...." }));
        combo_idLahanLiberica.setToolTipText("Silahkan pilih nomer lahan");
        panel_liberica.add(combo_idLahanLiberica, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 230, 160, 30));

        labelinformasi_libe3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelinformasi_libe3.setText("untuk ditanami kopi Liberica");
        panel_liberica.add(labelinformasi_libe3, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 310, 190, 20));

        labelinformasi_libe2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelinformasi_libe2.setText("merekomendasikan lahan ini");
        panel_liberica.add(labelinformasi_libe2, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 290, 180, 20));

        labelinformasi_libe1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        labelinformasi_libe1.setText("Klik tombol dibawah ini jika anda");
        panel_liberica.add(labelinformasi_libe1, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 270, 170, 20));

        btn_batalLiberica.setText("Batal");
        panel_liberica.add(btn_batalLiberica, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 400, 170, 40));

        btn_recomendasikan_liberica.setText("Recomendasikan");
        panel_liberica.add(btn_recomendasikan_liberica, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 340, 170, 40));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/analisisSppk.png"))); // NOI18N
        panel_liberica.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 970, 560));

        panel_content.add(panel_liberica, "card2");

        panel_dataLahan.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tableLahan.setFont(new java.awt.Font("Calibri", 0, 12));
        tableLahan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id"
            }
        ));
        tableLahan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tableLahan.setGridColor(new java.awt.Color(153, 153, 153));
        tableLahan.setSelectionBackground(new java.awt.Color(204, 204, 204));
        tableLahan.setSurrendersFocusOnKeystroke(true);
        jScrollPane1.setViewportView(tableLahan);

        panel_dataLahan.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, 860, 290));

        jLabel10.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel10.setText("Data Lahan");
        panel_dataLahan.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 114, 180, 30));

        jLabel18.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jLabel18.setText("Cari data");
        panel_dataLahan.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 120, 60, 40));

        field_cariLahan.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        field_cariLahan.setBorder(null);
        field_cariLahan.setOpaque(false);
        panel_dataLahan.add(field_cariLahan, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 120, 140, 30));
        panel_dataLahan.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 150, 140, 10));

        panel_content.add(panel_dataLahan, "card2");

        panel_dashboard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        labelKeteranganPemulihan.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        labelKeteranganPemulihan.setForeground(new java.awt.Color(153, 153, 153));
        labelKeteranganPemulihan.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelKeteranganPemulihan.setText("lahan ini merupakan........");
        labelKeteranganPemulihan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        panel_dashboard.add(labelKeteranganPemulihan, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 160, 140, 30));

        labelKeteranganMasaPanen.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        labelKeteranganMasaPanen.setForeground(new java.awt.Color(153, 153, 153));
        labelKeteranganMasaPanen.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelKeteranganMasaPanen.setText("lahan ini merupakan........");
        labelKeteranganMasaPanen.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        panel_dashboard.add(labelKeteranganMasaPanen, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 160, 140, 30));

        labelKeteranganArabica.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        labelKeteranganArabica.setForeground(new java.awt.Color(153, 153, 153));
        labelKeteranganArabica.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelKeteranganArabica.setText("lahan ini merupakan........");
        labelKeteranganArabica.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        panel_dashboard.add(labelKeteranganArabica, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 160, 140, 30));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/ezgif.com-gif-maker.gif"))); // NOI18N
        panel_dashboard.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 290, 850, 250));

        labelKeteranganRobusta.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        labelKeteranganRobusta.setForeground(new java.awt.Color(153, 153, 153));
        labelKeteranganRobusta.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelKeteranganRobusta.setText("lahan ini merupakan........");
        labelKeteranganRobusta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        panel_dashboard.add(labelKeteranganRobusta, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, 150, 30));

        labelKeteranganLiberica.setFont(new java.awt.Font("Calibri", 1, 12)); // NOI18N
        labelKeteranganLiberica.setForeground(new java.awt.Color(153, 153, 153));
        labelKeteranganLiberica.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        labelKeteranganLiberica.setText("lahan ini merupakan........");
        labelKeteranganLiberica.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        panel_dashboard.add(labelKeteranganLiberica, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 160, 130, 30));

        btn_DashLiberica.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/dashKepala2.png"))); // NOI18N
        btn_DashLiberica.setBorderPainted(false);
        btn_DashLiberica.setContentAreaFilled(false);
        btn_DashLiberica.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_DashLiberica.setFocusPainted(false);
        btn_DashLiberica.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_DashLiberica.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/dashKepala22.png"))); // NOI18N
        panel_dashboard.add(btn_DashLiberica, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 50, 190, 150));

        btn_DashArabica.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/dashKepala3.png"))); // NOI18N
        btn_DashArabica.setBorderPainted(false);
        btn_DashArabica.setContentAreaFilled(false);
        btn_DashArabica.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_DashArabica.setFocusPainted(false);
        btn_DashArabica.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_DashArabica.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/dashKepala33.png"))); // NOI18N
        panel_dashboard.add(btn_DashArabica, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 50, 190, 150));

        btn_DashPanen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/dashKepala4.png"))); // NOI18N
        btn_DashPanen.setBorderPainted(false);
        btn_DashPanen.setContentAreaFilled(false);
        btn_DashPanen.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_DashPanen.setFocusPainted(false);
        btn_DashPanen.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_DashPanen.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/dashKepala44.png"))); // NOI18N
        panel_dashboard.add(btn_DashPanen, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 50, 190, 150));

        btn_DashPemulihan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/dashKepala5.png"))); // NOI18N
        btn_DashPemulihan.setBorderPainted(false);
        btn_DashPemulihan.setContentAreaFilled(false);
        btn_DashPemulihan.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_DashPemulihan.setFocusPainted(false);
        btn_DashPemulihan.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_DashPemulihan.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/dashKepala55.png"))); // NOI18N
        panel_dashboard.add(btn_DashPemulihan, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 50, 190, 150));

        btn_Dashrobusta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/dashKepala1.png"))); // NOI18N
        btn_Dashrobusta.setBorderPainted(false);
        btn_Dashrobusta.setContentAreaFilled(false);
        btn_Dashrobusta.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btn_Dashrobusta.setFocusPainted(false);
        btn_Dashrobusta.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_Dashrobusta.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/image/dashKepala11.png"))); // NOI18N
        panel_dashboard.add(btn_Dashrobusta, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 190, 150));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/backDasboard.png"))); // NOI18N
        panel_dashboard.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 950, 560));

        panel_content.add(panel_dashboard, "card2");

        jPanel1.add(panel_content, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 90, 970, 610));

        jLabel4.setBackground(new java.awt.Color(255, 255, 153));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 80, 970, 600));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new v_cardKepala().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAnalisis_Liberica;
    private javax.swing.JButton btnAnalisis_arabica;
    private javax.swing.JButton btnAnalisis_robusta;
    private javax.swing.JButton btn_DashArabica;
    private javax.swing.JButton btn_DashLiberica;
    private javax.swing.JButton btn_DashPanen;
    private javax.swing.JButton btn_DashPemulihan;
    private javax.swing.JButton btn_Dashrobusta;
    private javax.swing.JButton btn_Liberica;
    private javax.swing.JButton btn_arabica;
    private javax.swing.JButton btn_batalLiberica;
    private javax.swing.JButton btn_batalRobusta;
    private javax.swing.JButton btn_batal_arabica;
    private javax.swing.JButton btn_dashboard;
    private javax.swing.JButton btn_dataLahan;
    private javax.swing.JButton btn_logout;
    private javax.swing.JButton btn_minimize;
    private javax.swing.JButton btn_recomendasikan_arabica;
    private javax.swing.JButton btn_recomendasikan_liberica;
    private javax.swing.JButton btn_recomendasikan_robusta;
    private javax.swing.JButton btn_robusta;
    private javax.swing.JComboBox<String> combo_idLahan;
    private javax.swing.JComboBox<String> combo_idLahanArabica;
    private javax.swing.JComboBox<String> combo_idLahanLiberica;
    private javax.swing.JTextField field_cariLahan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JLabel labelHasil;
    private javax.swing.JLabel labelHasilLiberica;
    private javax.swing.JLabel labelHasil_arabica;
    private javax.swing.JLabel labelKeteranganArabica;
    private javax.swing.JLabel labelKeteranganLiberica;
    private javax.swing.JLabel labelKeteranganMasaPanen;
    private javax.swing.JLabel labelKeteranganPemulihan;
    private javax.swing.JLabel labelKeteranganRobusta;
    private javax.swing.JLabel label_TTanah;
    private javax.swing.JLabel label_TTanah1;
    private javax.swing.JLabel label_TTanah2;
    private javax.swing.JLabel label_curahHujan;
    private javax.swing.JLabel label_curahHujan1;
    private javax.swing.JLabel label_curahHujan2;
    private javax.swing.JLabel label_drainase;
    private javax.swing.JLabel label_drainase1;
    private javax.swing.JLabel label_drainase2;
    private javax.swing.JLabel label_erosi;
    private javax.swing.JLabel label_erosi1;
    private javax.swing.JLabel label_erosi2;
    private javax.swing.JLabel label_ketinggian;
    private javax.swing.JLabel label_ketinggian1;
    private javax.swing.JLabel label_ketinggian2;
    private javax.swing.JLabel label_lereng;
    private javax.swing.JLabel label_lereng1;
    private javax.swing.JLabel label_lereng2;
    private javax.swing.JLabel label_rhb;
    private javax.swing.JLabel label_rhb1;
    private javax.swing.JLabel label_rhb2;
    private javax.swing.JLabel label_rhc;
    private javax.swing.JLabel label_rhc1;
    private javax.swing.JLabel label_rhc2;
    private javax.swing.JLabel label_suhu;
    private javax.swing.JLabel label_suhu1;
    private javax.swing.JLabel label_suhu2;
    private javax.swing.JLabel labelinformasi_ara1;
    private javax.swing.JLabel labelinformasi_ara2;
    private javax.swing.JLabel labelinformasi_ara3;
    private javax.swing.JLabel labelinformasi_libe1;
    private javax.swing.JLabel labelinformasi_libe2;
    private javax.swing.JLabel labelinformasi_libe3;
    private javax.swing.JLabel labelinformasi_robu1;
    private javax.swing.JLabel labelinformasi_robu2;
    private javax.swing.JLabel labelinformasi_robu3;
    private javax.swing.JPanel panel_arabica;
    private javax.swing.JPanel panel_content;
    private javax.swing.JPanel panel_dashboard;
    private javax.swing.JPanel panel_dataLahan;
    private javax.swing.JPanel panel_header;
    private javax.swing.JPanel panel_liberica;
    private javax.swing.JPanel panel_robusta;
    private javax.swing.JPanel panel_sideBar;
    javax.swing.JTable tableLahan;
    // End of variables declaration//GEN-END:variables
}
