package controller;

import java.awt.Color;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.plaf.basic.BasicBorders;
import model.m_pengguna;
import views.v_cardKepala;
import views.v_card_PegawaiLahan;

public class c_akses_pegawai {

    private v_card_PegawaiLahan is_v;
    private String username;
    private model.m_pengguna is_m;
    private ImageIcon activeBTN, offBtn,
            lahanactive, RobustaActive, ArabicaActive, LibericaAktie,
            offLahan, offRobusta, offArabica, offLiberica, activeDash,
            unactiveDash, activeLah, unactiveLah, activeVerified, unActiveVerified;

    public c_akses_pegawai(String username) throws SQLException {
        this.username = username;
        is_m = new m_pengguna();
        is_v = new v_card_PegawaiLahan();
        is_v.setVisible(true);
        is_v.getPanel_content().removeAll();
        is_v.getPanel_content().repaint();
        is_v.getPanel_content().revalidate();
        is_v.getTableLahan(is_m.getData_Lahan());
        is_v.getTableRobusta(is_m.getData_Robusta());
        is_v.getTableArabica(is_m.getData_Arabica());
        is_v.getTableLiberica(is_m.getData_Liberica());
        is_v.getTable_VerifiedLahan(is_m.getData_verifiedLAhan());
        is_v.getLabelRobusta().setText(is_m.getJumlahRobusta_Tanam() + " Lahan dalam fase tanam Robusta");
        is_v.getLabelArabica().setText(is_m.getJumlahArabica_Tanam() + " Lahan dalam fase tanam Arabica");
        is_v.getLabelLiberica().setText(is_m.getJumlahLiberica_Tanam() + " Lahan dalam fase tanam Liberica");

        is_v.getPanel_content().add(is_v.getPanel_dashboard());
        is_v.getPanel_content().repaint();
        is_v.getPanel_content().revalidate();
        is_v.getBtn_dashboard().setRolloverEnabled(false);

        this.activeDash = new ImageIcon(getClass().getResource("/image/activeDashboard.png"));
        this.unactiveDash = new ImageIcon(getClass().getResource("/image/unactiveDashboard.png"));
        this.activeLah = new ImageIcon(getClass().getResource("/image/activeLahan.png"));
        this.unactiveLah = new ImageIcon(getClass().getResource("/image/unactiveLahan.png"));
        this.activeVerified = new ImageIcon(getClass().getResource("/image/vrikasiLahan_Active.png"));
        this.unActiveVerified = new ImageIcon(getClass().getResource("/image/vrikasiLahan_unActive.png"));

        this.activeBTN = new ImageIcon(getClass().getResource("/image/activeBtn2.png"));
        this.lahanactive = new ImageIcon(getClass().getResource("/image/btnLahan2.png"));
        this.RobustaActive = new ImageIcon(getClass().getResource("/image/btnRobusta2.png"));
        this.ArabicaActive = new ImageIcon(getClass().getResource("/image/btnArabica2.png"));
        this.LibericaAktie = new ImageIcon(getClass().getResource("/image/btnLiberica2.png"));
        this.offBtn = new ImageIcon(getClass().getResource("/image/awalBtn_1_1.png"));
        this.offLahan = new ImageIcon(getClass().getResource("/image/btnLahan1.png"));
        this.offRobusta = new ImageIcon(getClass().getResource("/image/btnRobusta1.png"));
        this.offArabica = new ImageIcon(getClass().getResource("/image/btnArabica1.png"));
        this.offLiberica = new ImageIcon(getClass().getResource("/image/btnLiberica1.png"));

        is_v.getBtn_dashboard().setIcon(activeDash);
        is_v.getBtn_dashboard().setRolloverEnabled(false);
        is_v.getBtn_dataLahan().setRolloverEnabled(false);
        is_v.getBtn_verifikasiLahan().setRolloverEnabled(false);
        is_v.getBtn_dashboard().addActionListener(new dashboard_Listener());
        is_v.getBtn_dataLahan().addActionListener(new lahanDataLahan_Listener());
        is_v.getBtn_logout().addActionListener(new log_Out_Listener());
        is_v.getBtn_minimize().addMouseListener(new minimizeListener());
        is_v.getBtn_subLahan().addActionListener(new subLahan_Listener());
        is_v.getBtn_subRobusta().addActionListener(new subRobusta_Listener());
        is_v.getBtn_subArabica().addActionListener(new subArabica_Listener());
        is_v.getBtn_subLiberica().addActionListener(new subLiberica_Listener());
        is_v.getBtn_addLahan().addActionListener(new tambah_LahanListener());
        is_v.getBtn_verifikasiLahan().addActionListener(new verified_TanamLahan_Listener());

        is_v.getField_cariLahan().addKeyListener(new java.awt.event.KeyListener() {

            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                String cek = is_v.getField_cariLahan().getText() + "";
                try {
                    is_v.getTableLahan(is_m.getCariData_Lahan(cek));
                } catch (SQLException ex) {
                    Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        });
        is_v.getField_cariRobusta().addKeyListener(new java.awt.event.KeyListener() {

            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                String cek = is_v.getField_cariRobusta().getText() + "";
                try {
                    is_v.getTableRobusta(is_m.getCariData_Robusta(cek));
                } catch (SQLException ex) {
                    Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        });
        is_v.getField_cariArabica().addKeyListener(new java.awt.event.KeyListener() {

            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                String cek = is_v.getField_cariArabica().getText() + "";
                try {
                    is_v.getTableArabica(is_m.getCariData_Arabica(cek));
                } catch (SQLException ex) {
                    Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        });
        is_v.getField_cariLiberica().addKeyListener(new java.awt.event.KeyListener() {

            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                String cek = is_v.getField_cariLiberica().getText() + "";
                try {
                    is_v.getTableLiberica(is_m.getCariData_Liberica(cek));
                } catch (SQLException ex) {
                    Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        });

        is_v.getTabel_verifiedLahan().addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    String selectStatus = is_v.showMessageOption_VerifiedLahan("Silahkan pilih status lahan nomer " + is_v.getId_TableVerifiedLahan());
                    if (is_m.updateStatusLahan_eksekusiTanam(is_v.getId_TableVerifiedLahan(), is_m.getID_Status(selectStatus) + "")) {
                        is_v.shoeMessage("Status Lahan " + is_v.getId_TableVerifiedLahan() + " berhasil dimasukkan");
                        is_v.getTable_VerifiedLahan(is_m.getData_verifiedLAhan());
                    } else {
                        System.out.println("Gagal ngubah status");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        );
 
        is_v.getTableLahan().addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    String data[] = is_m.getLahan_Edit(is_v.getTableID_Lahan());
                    String dataChange[] = new String[11];
                    dataChange[0] = data[0];
                    dataChange[1] = data[1];

                    dataChange[2] = is_v.showMessageOPtion_Edit("Nilai RHB", data[2]);
                    while (dataChange[2].equals("")) {
                        dataChange[2] = is_v.showMessageOPtion_Edit("Nilai RHB", data[2]);
                    }
                    dataChange[3] = is_v.showMessageOPtion_Edit("Nilai RHC", data[3]);
                    while (dataChange[3].equals("")) {
                        dataChange[3] = is_v.showMessageOPtion_Edit("Nilai RHC", data[3]);
                    }
                    dataChange[4] = is_v.showMessageOPtion_Edit("Nilai Suhu", data[4]);
                    while (dataChange[4].equals("")) {
                        dataChange[4] = is_v.showMessageOPtion_Edit("Nilai Suhu", data[4]);
                    }
                    dataChange[5] = is_v.showMessageOPtion_Edit("Nilai Curah Hujan", data[5]);
                    while (dataChange[5].equals("")) {
                        dataChange[5] = is_v.showMessageOPtion_Edit("Nilai Curah Hujan", data[5]);
                    }
                    dataChange[6] = is_v.showMessageOPtion_Add("Tekstur Tanah");
                    while (dataChange[6].equals("")) {
                        dataChange[6] = is_v.showMessageOPtion_Add("Tekstur Tanah");
                    }
                    dataChange[7] = is_v.showMessageOption_drainase("Drainase");
                    while (dataChange[7].equals("")) {
                        dataChange[7] = is_v.showMessageOption_drainase("Drainase");
                    }
                    dataChange[8] = is_v.showMessageOPtion_Edit("Nilai Ketinggian", data[8]);
                    while (dataChange[8].equals("")) {
                        dataChange[8] = is_v.showMessageOPtion_Edit("Nilai Ketinggian", data[8]);
                    }
                    dataChange[9] = is_v.showMessageOption_eroSi("Erosi");
                    while (dataChange[9].equals("")) {
                        dataChange[9] = is_v.showMessageOption_eroSi("Erosi");
                    }
                    dataChange[10] = is_v.showMessageOPtion_Edit("Nilai Lereng", data[10]);
                    while (dataChange[10].equals("")) {
                        dataChange[10] = is_v.showMessageOPtion_Edit("Nilai Lereng", data[10]);
                    }
                    for (int i = 0; i < dataChange.length; i++) {
                        System.out.println(dataChange[i]);
                    }
                    if (is_m.updateLahan(dataChange[0], dataChange[2], dataChange[3], dataChange[4], dataChange[5], dataChange[6],
                            dataChange[7], dataChange[8], dataChange[9], dataChange[10])) {
                        is_v.shoeMessage("Data No " + is_v.getTableID_Lahan() + " berhasil diperbarui");
                        is_v.getTableLahan(is_m.getData_Lahan());
                    } else {
                        is_v.shoeMessage("Terjadi Kesalahan");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }
        );
        is_v.getTabelRobusta().addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String statusLahan = is_v.showMessageOption_statusLahan("Pilih status lahan");
                try {
                    is_m.updateStatusLahan(is_m.getID_Status(statusLahan) + "", is_v.getTableID_Robusta());
                    is_v.getTableRobusta(is_m.getData_Robusta());
                } catch (SQLException ex) {
                    Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }
        );
        is_v.getTabel_arabica().addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String statusLahan = is_v.showMessageOption_statusLahan("Pilih status lahan");
                try {
                    is_m.updateStatusLahan(is_m.getID_Status(statusLahan) + "", is_v.getTableID_Arabica());
                    is_v.getTableArabica(is_m.getData_Arabica());
                } catch (SQLException ex) {
                    Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }
        );
        is_v.getTabel_liberica().addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String statusLahan = is_v.showMessageOption_statusLahan("Pilih status lahan");
                try {
                    is_m.updateStatusLahan(is_m.getID_Status(statusLahan) + "", is_v.getTableID_Liberica());
                    is_v.getTableLiberica(is_m.getData_Liberica());
                } catch (SQLException ex) {
                    Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }
        );
        
    }

    private class dashboard_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            is_v.getPanel_content().removeAll();
            is_v.getPanel_content().revalidate();
            is_v.getPanel_content().repaint();
            is_v.getPanel_content().add(is_v.getPanel_dashboard());
            is_v.getPanel_content().revalidate();
            is_v.getPanel_content().repaint();
            is_v.getBtn_dashboard().setIcon(activeDash);
            is_v.getBtn_dataLahan().setIcon(unactiveLah);
            is_v.getBtn_verifikasiLahan().setIcon(unActiveVerified);
            try {
                is_v.getLabelRobusta().setText(is_m.getJumlahRobusta_Tanam() + " Lahan dalam fase tanam Robusta");
                is_v.getLabelArabica().setText(is_m.getJumlahArabica_Tanam() + " Lahan dalam fase tanam Arabica");
                is_v.getLabelLiberica().setText(is_m.getJumlahLiberica_Tanam() + " Lahan dalam fase tanam Liberica");
            } catch (SQLException ex) {
                Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    private class verified_TanamLahan_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            is_v.getPanel_content().removeAll();
            is_v.getPanel_content().revalidate();
            is_v.getPanel_content().repaint();
            is_v.getPanel_content().add(is_v.getPanel_verifikasi_Tanam());
            is_v.getPanel_content().revalidate();
            is_v.getPanel_content().repaint();
            is_v.getBtn_verifikasiLahan().setIcon(activeVerified);
            is_v.getBtn_dataLahan().setIcon(unactiveLah);
            is_v.getBtn_dashboard().setIcon(unactiveDash);
        }

    }

    private class lahanDataLahan_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            is_v.getPanel_content().removeAll();
            is_v.getPanel_content().repaint();
            is_v.getPanel_content().revalidate();
            is_v.getPanel_content().add(is_v.getPanel_dataLahan());
            is_v.getPanel_content().repaint();
            is_v.getBtn_dashboard().setIcon(unactiveDash);
            is_v.getBtn_dataLahan().setIcon(activeLah);
            is_v.getBtn_verifikasiLahan().setIcon(unActiveVerified);
        }

    }

    private class log_Out_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (is_v.showOption("Anda Yakin akan keluar") == JOptionPane.OK_OPTION) {
                try {
                    is_v.dispose();
                    new c_pengguna(1);
                } catch (SQLException ex) {
                    Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }


    private class tambah_LahanListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            String rhb = null, rhc, suhu, curahHUjan, lereng, ketinggian;
            String tanah, drainase = null, erosi = null;
            String statusLahan = is_v.showMessageOption_statusLahan("Lahan");
            rhb = is_v.showMessage_Add("Masukkan Nilai RHB");
            while (rhb.isEmpty()) {
                rhb = is_v.showMessage_Add("Masukkan Nilai RHB");
            }
            rhc = is_v.showMessage_Add("Masukkan Nilai RHC");
            while (rhc.isEmpty()) {
                rhc = is_v.showMessage_Add("Masukkan Nilai RHC");
            }
            suhu = is_v.showMessage_Add("Masukkan Nilai Suhu");
            while (suhu.isEmpty()) {
                suhu = is_v.showMessage_Add("Masukkan Nilai Suhu");
            }
            curahHUjan = is_v.showMessage_Add("Masukkan Nilai Curah Hujan");
            while (curahHUjan.isEmpty()) {
                curahHUjan = is_v.showMessage_Add("Masukkan Nilai Curah Hujan");
            }
            tanah = is_v.showMessageOPtion_Add("Masukkan Nilai Struktur Tanah Lahan");
            drainase = is_v.showMessageOption_drainase("Drainase penyiraman pada lahan");
            ketinggian = is_v.showMessage_Add("Masukkan ketinggian lahan diatas permukaan laut");
            while (ketinggian.isEmpty()) {
                ketinggian = is_v.showMessage_Add("Masukkan ketinggian lahan diatas permukaan laut");
            }
            erosi = is_v.showMessageOption_eroSi("Resiko terjadinya erosi pada lahan");
            lereng = is_v.showMessage_Add("Masukkan nilai kelerengan lahan");
            while (lereng.isEmpty()) {
                lereng = is_v.showMessage_Add("Masukkan nilai kelerengan lahan");
            }
            try {
                is_m.insertLahanBaru(is_m.getID_Status(statusLahan), Integer.parseInt(rhb), Integer.parseInt(rhc), Integer.parseInt(suhu),
                        Integer.parseInt(curahHUjan), tanah, drainase, Integer.parseInt(ketinggian), erosi, Integer.parseInt(lereng));
                is_v.getTableLahan(is_m.getData_Lahan());
            } catch (SQLException ex) {
                Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class minimizeListener implements MouseListener {

        @Override
        public void mouseClicked(MouseEvent e) {
            minimizeAction();
        }

        @Override
        public void mousePressed(MouseEvent e) {
        }

        @Override
        public void mouseReleased(MouseEvent e) {
        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }

    }

    private void minimizeAction() {
        is_v.minimize();
    }

//    menu sub lahan 
    private class subLahan_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                is_v.getTableLahan(is_m.getData_Lahan());
            } catch (SQLException ex) {
                Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
            }
            is_v.getPanelContainerLahan().removeAll();
            is_v.getPanelContainerLahan().repaint();
            is_v.getPanelContainerLahan().revalidate();
            is_v.getPanelContainerLahan().add(is_v.getPanel_sub_lahan());
            is_v.getPanelContainerLahan().repaint();
            is_v.getPanelContainerLahan().revalidate();
            is_v.getPanelContainerLahan().revalidate();
            is_v.getBtn_subLahan().setIcon(lahanactive);
            is_v.getBtn_subRobusta().setIcon(offRobusta);
            is_v.getBtn_subArabica().setIcon(offArabica);
            is_v.getBtn_subLiberica().setIcon(offLiberica);
        }

    }

    private class subRobusta_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            is_v.getPanelContainerLahan().removeAll();
            is_v.getPanelContainerLahan().repaint();
            is_v.getPanelContainerLahan().revalidate();
            is_v.getPanelContainerLahan().add(is_v.getPanel_sub_robusta());
            is_v.getPanelContainerLahan().repaint();
            is_v.getPanelContainerLahan().revalidate();
            is_v.getBtn_subLahan().setIcon(offLahan);
            is_v.getBtn_subRobusta().setIcon(RobustaActive);
            is_v.getBtn_subArabica().setIcon(offArabica);
            is_v.getBtn_subLiberica().setIcon(offLiberica);
            try {
                is_v.getTableRobusta(is_m.getData_Robusta());
            } catch (SQLException ex) {
                Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

    private class subArabica_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            is_v.getPanelContainerLahan().removeAll();
            is_v.getPanelContainerLahan().repaint();
            is_v.getPanelContainerLahan().revalidate();
            is_v.getPanelContainerLahan().add(is_v.getPanel_sub_arabica());
            is_v.getPanelContainerLahan().repaint();
            is_v.getPanelContainerLahan().revalidate();
            is_v.getBtn_subLahan().setIcon(offLahan);
            is_v.getBtn_subRobusta().setIcon(offRobusta);
            is_v.getBtn_subArabica().setIcon(ArabicaActive);
            is_v.getBtn_subLiberica().setIcon(offLiberica);
            try {
                is_v.getTableArabica(is_m.getData_Arabica());
            } catch (SQLException ex) {
                Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    private class subLiberica_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            is_v.getPanelContainerLahan().removeAll();
            is_v.getPanelContainerLahan().repaint();
            is_v.getPanelContainerLahan().revalidate();
            is_v.getPanelContainerLahan().add(is_v.getPanel_sub_Liberica());
            is_v.getPanelContainerLahan().repaint();
            is_v.getPanelContainerLahan().revalidate();
            is_v.getBtn_subLahan().setIcon(offLahan);
            is_v.getBtn_subRobusta().setIcon(offRobusta);
            is_v.getBtn_subArabica().setIcon(offArabica);
            is_v.getBtn_subLiberica().setIcon(LibericaAktie);
            try {
                is_v.getTableLiberica(is_m.getData_Liberica());
            } catch (SQLException ex) {
                Logger.getLogger(c_akses_pegawai.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

}
