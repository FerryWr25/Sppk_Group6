/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import koneksi.connection;

/**
 *
 * @author helmets
 */
public class m_master {

    connection con;
    private ImageIcon a;

    public m_master() throws SQLException {
        con = new connection();
        this.a = new ImageIcon(getClass().getResource("/image/btnLiberica2.png"));
    }

    protected int checkId(String query) throws SQLException {
        int id = 0;
        ResultSet hasil;
        do {
            id++;
            hasil = con.getResult(query + id);
        } while (hasil.next());
        return id;
    }

    protected String[] getData_ID(String Query, String Data[]) throws SQLException {
        ResultSet rs = con.getResult(Query);
        if (rs.next()) {
            for (int i = 0; i < Data.length; i++) {
                Data[i] = rs.getString(i + 1);
            }
        }
        return Data;
    }

    protected boolean getStatusQuery(String query) {
        boolean succesInput = false;
        try {
            con.executeQuery(query);
            succesInput = true;
        } catch (SQLException ex) {
            succesInput = false;
        }
        return succesInput;
    }

    protected double getDataDouble(String query) throws SQLException {
        ResultSet hasil = con.getResult(query);
        hasil.next();
        double data = hasil.getDouble(1);
        return data;
    }

    protected int getDataInt(String query) throws SQLException {
        ResultSet hasil = con.getResult(query);
        hasil.next();
        int data = hasil.getInt(1);
        return data;
    }

    protected String getDataString(String query) throws SQLException {
        ResultSet hasil = con.getResult(query);
        hasil.next();
        String data = hasil.getString(1).toLowerCase();
        return data;
    }

    protected DefaultTableModel getDataTabel(String kolom[], String query) throws SQLException {
        DefaultTableModel table = new DefaultTableModel(null, kolom);
        ResultSet rs = con.getResult(query);
        while (rs.next()) {
            String row[] = new String[kolom.length];
            for (int i = 0; i < row.length; i++) {
                row[i] = rs.getString(i + 1).toLowerCase();
            }
            table.addRow(row);
        }

        return table;
    }
}
