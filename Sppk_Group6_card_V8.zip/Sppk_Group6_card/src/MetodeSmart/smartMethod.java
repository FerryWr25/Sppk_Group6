/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MetodeSmart;

/**
 *
 * @author helmets
 */
public class smartMethod {

    int nRhc, nRhb, nSuhu, nCHujan, nTanah, nDrainase, nKetinggian, nErosi, nLereng;
    double hasil;
    public smartMethod(double rhb, double rhc, int suhu, int curah_hujan, String tanah, String drainase, int ketinggian, String erosi, int lereng) {
        if (rhb > 6.6 && rhb < 7.3) {
            nRhb = 1;
        } else if (rhb >= 5.6 && rhb < 6.6) {
            nRhb = 3;
        } else {
            nRhb = 2;
        }

        if (rhc >= 1.2) {
            nRhc = 3;
        } else if (rhc >= 0.8 && rhc < 1.2) {
            nRhc = 2;
        } else {
            nRhc = 1;
        }

        if (suhu > 25) {
            nSuhu = 1;
        } else if (suhu >= 15 && suhu < 25) {
            nSuhu = 4;
        } else if (suhu >= 10 && suhu < 15) {
            nSuhu = 2;
        } else {
            nSuhu = 3;
        }

        if (curah_hujan > 3000) {
            nCHujan = 3;
        } else if (curah_hujan >= 2000 && curah_hujan < 3000) {
            nCHujan = 4;
        } else if (curah_hujan >= 1200 && curah_hujan < 2000) {
            nCHujan = 2;
        } else {
            nCHujan = 1;
        }

        if (tanah.equalsIgnoreCase("halus")) {
            nTanah = 3;
        } else if (tanah.equalsIgnoreCase("agak halus")) {
            nTanah = 4;
        } else if (tanah.equalsIgnoreCase("agak kasar")) {
            nTanah = 2;
        } else {
            nTanah = 1;
        }

        if (drainase.equalsIgnoreCase("baik")) {
            nDrainase = 3;
        } else if (drainase.equalsIgnoreCase("agak terhambat")) {
            nDrainase = 2;
        } else {
            nDrainase = 1;
        }

        if (ketinggian > 2000) {
            nKetinggian = 3;
        } else if (ketinggian >= 1500 && ketinggian < 2000) {
            nKetinggian = 4;
        } else if (ketinggian >= 1000 && ketinggian < 1500) {
            nKetinggian = 2;
        } else {
            nKetinggian = 1;
        }

        if (erosi.equalsIgnoreCase("rendah")) {
            nErosi = 3;
        } else if (erosi.equalsIgnoreCase("sedang")) {
            nErosi = 2;
        } else {
            nErosi = 1;
        }

        if (lereng < 8) {
            nLereng = 1;
        } else if (lereng >= 8 && lereng < 16) {
            nLereng = 3;
        } else {
            nLereng = 2;
        }
        double Cast_uRhb = Double.parseDouble(nRhb+"");
        double Cast_uRhc = Double.parseDouble(nRhc+"");
        double Cast_uSuhu = Double.parseDouble(nSuhu+"");
        double Cast_uCHujan = Double.parseDouble(nCHujan+"");
        double Cast_uTanah = Double.parseDouble(nTanah+"");
        double Cast_uDrainase = Double.parseDouble(nDrainase+"");
        double Cast_uKetinggian = Double.parseDouble(nKetinggian+"");
        double Cast_uErosi = Double.parseDouble(nErosi+"");
        double Cast_uLereng = Double.parseDouble(nLereng+"");
        
        double uRhb = ((Cast_uRhb - 1) / (3 - 1));
        double uRhc = ((Cast_uRhc - 1) / (3 - 1));
        double uSuhu = ((Cast_uSuhu - 1) / (4 - 1));
        double uCHujan = ((Cast_uCHujan - 1) / (4 - 1));
        double uTanah = ((Cast_uTanah - 1) / (4 - 1));
        double uDrainase = ((Cast_uDrainase - 1) / (3 - 1));
        double uKetinggian = ((Cast_uKetinggian - 1) / (4 - 1));
        double uErosi = ((Cast_uErosi - 1) / (3 - 1));
        double uLereng = ((Cast_uLereng - 1) / (3 - 1));

        double nBobot_rhb = 0.1;
        double nBobot_rhc = 0.09;
        double nBobot_suhu = 0.1;
        double nBobot_chujan = 0.08;
        double nBobot_tanah = 0.15;
        double nBobot_drainase = 0.15;
        double nBobot_ketinggian = 0.09;
        double nBobot_erosi = 0.1;
        double nBobot_lereng = 0.14;
        System.out.println(nRhb+" nilai rhb");
        System.out.println(nRhc+" nilai rhc");
        System.out.println(nSuhu+" nilai suhu");
        System.out.println(nCHujan+" nilai cHujan");
        System.out.println(nTanah+" nilai tanah");
        System.out.println(nDrainase+" nilai drainase");
        System.out.println(nKetinggian+" nilai ketinggian");
        System.out.println(nErosi+" nilai erosi");
        System.out.println(nLereng+" nilai lereng");
        System.out.println(uRhb);
        System.out.println(uRhc);
        System.out.println(uSuhu);
        System.out.println(uCHujan);
        System.out.println(uTanah);
        System.out.println(uDrainase);
        System.out.println(uKetinggian);
        System.out.println(uErosi);
        System.out.println(uLereng);
        hasil = ((uRhb * nBobot_rhb) + (uRhc * nBobot_rhc) + (uSuhu * nBobot_suhu) + (uCHujan * nBobot_chujan)
                + (uTanah * nBobot_tanah) + (uDrainase * nBobot_drainase) + (uKetinggian * nBobot_ketinggian)
                + (uErosi * nBobot_erosi) + (uLereng * nBobot_lereng));
    }

    public double getHasil() {
        return hasil;
    }

}
